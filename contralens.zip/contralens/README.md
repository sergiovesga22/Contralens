# README - ContraLens

## Descripción
ContraLens es una aplicación personal para la gestión y supervisión integral de contratos. Permite centralizar toda la información relacionada con contratos, facilitando su seguimiento, supervisión y generación de reportes.

## Características Principales
- Dashboard con estadísticas y visualizaciones
- Gestión completa de contratos (CRUD)
- Sistema de supervisión con alertas
- Generación de reportes personalizables
- Interfaz de usuario intuitiva y responsive

## Estructura del Proyecto
```
contralens/
├── backend/              # API RESTful con Node.js
│   ├── config/           # Configuraciones
│   ├── controllers/      # Controladores de la API
│   ├── models/           # Modelos de datos
│   ├── routes/           # Definición de rutas
│   ├── middleware/       # Middleware
│   ├── utils/            # Utilidades
│   ├── .env              # Variables de entorno
│   └── server.js         # Punto de entrada
│
├── frontend/             # Aplicación web frontend
│   ├── css/              # Estilos CSS
│   ├── js/               # Scripts JavaScript
│   │   └── modules/      # Módulos JS organizados
│   ├── img/              # Imágenes y recursos
│   └── index.html        # Página principal
│
├── database/             # Scripts SQL para la base de datos
│   ├── schema.sql        # Estructura de la base de datos
│   └── sample-data.sql   # Datos de ejemplo
│
├── start.sh              # Script de inicio para Linux/macOS
├── start.bat             # Script de inicio para Windows
├── guia_usuario.md       # Guía detallada para usuarios
└── verificacion.md       # Guía de verificación de funcionalidad
```

## Requisitos
- Node.js 14.0 o superior
- MySQL 5.7 o superior (o XAMPP/WAMP/MAMP)
- Navegador web moderno

## Inicio Rápido
1. Configura la base de datos MySQL (ver guía_usuario.md para instrucciones detalladas)
2. Actualiza las credenciales de la base de datos en `backend/.env`
3. Ejecuta `start.bat` (Windows) o `./start.sh` (Linux/macOS)

## Documentación
Para instrucciones detalladas sobre instalación, configuración y uso, consulta el archivo `guia_usuario.md`.

## Licencia
Este proyecto es para uso personal.
