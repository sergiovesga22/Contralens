# Guía de Usuario - ContraLens

## Introducción

ContraLens es una aplicación personal diseñada para la gestión y supervisión integral de contratos. Esta herramienta te permite centralizar toda la información relacionada con tus contratos, facilitando su seguimiento, supervisión y generación de reportes.

## Requisitos del Sistema

- **Sistema Operativo**: Windows 7 o superior, macOS 10.12 o superior, o Linux
- **Navegador**: Chrome, Firefox, Edge o Safari (versiones actualizadas)
- **Base de Datos**: MySQL 5.7 o superior (o alternativas como XAMPP, WAMP, MAMP)
- **Node.js**: Versión 14.0 o superior

## Instalación

### 1. Instalación de Node.js

Si no tienes Node.js instalado:

1. Visita [https://nodejs.org/](https://nodejs.org/)
2. Descarga la versión LTS (recomendada para la mayoría de usuarios)
3. Sigue las instrucciones del instalador

Para verificar la instalación, abre una terminal o símbolo del sistema y ejecuta:
```
node --version
npm --version
```

### 2. Instalación de MySQL

#### Opción A: Instalación directa de MySQL (usuarios avanzados)

1. Descarga MySQL desde [https://dev.mysql.com/downloads/mysql/](https://dev.mysql.com/downloads/mysql/)
2. Sigue las instrucciones del instalador
3. Durante la instalación, establece una contraseña para el usuario root

#### Opción B: Instalación de XAMPP (recomendada para principiantes)

XAMPP es una solución todo-en-uno que incluye MySQL, PHP y Apache, facilitando la configuración:

1. Descarga XAMPP desde [https://www.apachefriends.org/](https://www.apachefriends.org/)
2. Instala XAMPP siguiendo las instrucciones del instalador
3. Inicia XAMPP Control Panel
4. Inicia los módulos "Apache" y "MySQL"

### 3. Configuración de la Base de Datos

#### Usando phpMyAdmin (incluido en XAMPP)

1. Abre tu navegador y ve a http://localhost/phpmyadmin/
2. Inicia sesión (usuario: "root", contraseña: la que estableciste durante la instalación, o vacía si usas XAMPP)
3. Crea una nueva base de datos:
   - Haz clic en "Nueva" en el panel izquierdo
   - Escribe "contralens" como nombre de la base de datos
   - En "Cotejamiento" selecciona "utf8mb4_unicode_ci"
   - Haz clic en "Crear"
4. Importa el esquema de la base de datos:
   - Selecciona la base de datos "contralens" recién creada
   - Haz clic en la pestaña "Importar"
   - Haz clic en "Examinar" y selecciona el archivo `database/schema.sql` de tu carpeta ContraLens
   - Haz clic en "Continuar"
5. Opcionalmente, importa los datos de ejemplo:
   - Repite el proceso de importación pero seleccionando el archivo `database/sample-data.sql`

#### Usando la línea de comandos (usuarios avanzados)

1. Abre una terminal o símbolo del sistema
2. Conéctate a MySQL:
   ```
   mysql -u root -p
   ```
3. Ingresa tu contraseña cuando te la solicite
4. Crea la base de datos:
   ```sql
   CREATE DATABASE contralens CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
5. Sal de MySQL:
   ```sql
   exit
   ```
6. Importa el esquema y los datos de ejemplo:
   ```
   mysql -u root -p contralens < ruta/a/contralens/database/schema.sql
   mysql -u root -p contralens < ruta/a/contralens/database/sample-data.sql
   ```

### 4. Configuración de la Aplicación

1. Abre el archivo `backend/.env` en un editor de texto
2. Actualiza la configuración de la base de datos:
   ```
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=tu_contraseña
   DB_NAME=contralens
   ```
   Reemplaza `tu_contraseña` con la contraseña que estableciste para MySQL

## Inicio Rápido

### Método 1: Usando los Scripts de Inicio

#### En Windows:
1. Haz doble clic en el archivo `start.bat`
2. Se abrirá una ventana de comandos y luego el navegador con la aplicación

#### En macOS o Linux:
1. Abre una terminal
2. Navega hasta la carpeta de ContraLens
3. Ejecuta:
   ```
   ./start.sh
   ```

### Método 2: Inicio Manual

1. Inicia el backend:
   - Abre una terminal o símbolo del sistema
   - Navega hasta la carpeta `backend` de ContraLens
   - Ejecuta:
     ```
     npm install  # Solo la primera vez
     node server.js
     ```

2. Abre el frontend:
   - Navega hasta la carpeta `frontend` de ContraLens
   - Abre el archivo `login.html` en tu navegador

## Acceso a la Aplicación

### Credenciales por Defecto
- **Email**: admin@contralens.com
- **Contraseña**: Admin123

## Uso de la Aplicación

### Dashboard

El dashboard te proporciona una visión general de tus contratos:

- **Estadísticas Clave**: Número total de contratos, contratos activos, en revisión y valor total
- **Contratos Próximos a Vencer**: Lista de contratos que vencerán pronto
- **Distribución por Estado**: Gráfico que muestra la distribución de contratos por estado

### Gestión de Contratos

En esta sección puedes:

1. **Ver Contratos**: Lista de todos tus contratos con opciones de filtrado
2. **Crear Contratos**: Haz clic en "Nuevo Contrato" y completa el formulario
3. **Editar Contratos**: Haz clic en el icono de edición junto al contrato que deseas modificar
4. **Eliminar Contratos**: Haz clic en el icono de eliminación (se pedirá confirmación)
5. **Filtrar Contratos**: Usa los filtros en la parte superior para encontrar contratos específicos

### Supervisión

Esta sección te permite:

1. **Ver Alertas**: Visualiza alertas de supervisión con prioridad alta
2. **Registrar Supervisión**: Haz clic en "Nueva Supervisión" para añadir observaciones a un contrato
3. **Filtrar Registros**: Filtra los registros de supervisión por contrato, prioridad o fecha

### Reportes

En esta sección puedes:

1. **Generar Reportes**: Selecciona el tipo de reporte y aplica filtros
2. **Exportar Reportes**: Exporta los resultados a Excel o PDF
3. **Guardar Reportes**: Guarda configuraciones de reportes para uso futuro
4. **Visualizar Datos**: Ve resúmenes y gráficos basados en los datos filtrados

## Solución de Problemas

### Problemas con la Base de Datos

#### Error: "No se puede conectar a la base de datos"
- Verifica que MySQL o XAMPP esté en ejecución
- Comprueba que las credenciales en el archivo `.env` sean correctas
- Asegúrate de que la base de datos "contralens" exista

#### Error: "Tabla no encontrada"
- Verifica que hayas importado correctamente el archivo `schema.sql`
- Comprueba que estés usando la base de datos correcta

### Problemas con el Backend

#### Error: "El servidor no responde"
- Verifica que Node.js esté instalado correctamente
- Comprueba que el servidor backend esté en ejecución
- Verifica que no haya otro servicio usando el puerto 3000

#### Error: "Módulo no encontrado"
- Ejecuta `npm install` en la carpeta `backend` para instalar todas las dependencias

### Problemas con el Frontend

#### Error: "No se puede cargar la página"
- Verifica que estés abriendo el archivo HTML correcto
- Comprueba que el servidor backend esté en ejecución
- Verifica la consola del navegador para errores JavaScript

## Respaldo y Mantenimiento

### Respaldo de la Base de Datos

#### Usando phpMyAdmin
1. Accede a phpMyAdmin (http://localhost/phpmyadmin/)
2. Selecciona la base de datos "contralens"
3. Haz clic en la pestaña "Exportar"
4. Selecciona "SQL" como formato
5. Haz clic en "Continuar" para descargar el archivo de respaldo

#### Usando la línea de comandos
```
mysqldump -u root -p contralens > contralens_backup.sql
```

### Restauración de la Base de Datos

#### Usando phpMyAdmin
1. Accede a phpMyAdmin
2. Selecciona la base de datos "contralens"
3. Haz clic en la pestaña "Importar"
4. Selecciona el archivo de respaldo
5. Haz clic en "Continuar"

#### Usando la línea de comandos
```
mysql -u root -p contralens < contralens_backup.sql
```

## Personalización

### Cambiar el Logo
1. Reemplaza el archivo `frontend/img/logo.png` con tu propio logo
2. Asegúrate de que el nuevo logo tenga dimensiones similares para mantener el diseño

### Cambiar Colores
1. Edita el archivo `frontend/css/styles_supervision.css`
2. Modifica las variables CSS en la sección `:root` para cambiar los colores principales

## Contacto y Soporte

Para soporte técnico o consultas, contacta a:
- Email: soporte@contralens.com
- Sitio web: www.contralens.com/soporte

---

Gracias por usar ContraLens. ¡Esperamos que esta herramienta te ayude a gestionar tus contratos de manera eficiente!
