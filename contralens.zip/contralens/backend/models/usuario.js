// Modelo para la gestión de usuarios
const { pool } = require('../config/database');
const bcrypt = require('bcrypt');

class Usuario {
  // Obtener todos los usuarios
  static async getAll() {
    try {
      const [rows] = await pool.query(
        'SELECT id, nombre, email, rol, fecha_creacion, fecha_actualizacion FROM usuarios'
      );
      return rows;
    } catch (error) {
      console.error('Error al obtener usuarios:', error);
      throw error;
    }
  }

  // Obtener usuario por ID
  static async getById(id) {
    try {
      const [rows] = await pool.query(
        'SELECT id, nombre, email, rol, fecha_creacion, fecha_actualizacion FROM usuarios WHERE id = ?',
        [id]
      );
      return rows[0];
    } catch (error) {
      console.error('Error al obtener usuario por ID:', error);
      throw error;
    }
  }

  // Obtener usuario por email
  static async getByEmail(email) {
    try {
      const [rows] = await pool.query(
        'SELECT * FROM usuarios WHERE email = ?',
        [email]
      );
      return rows[0];
    } catch (error) {
      console.error('Error al obtener usuario por email:', error);
      throw error;
    }
  }

  // Crear nuevo usuario
  static async create(userData) {
    try {
      // Encriptar contraseña
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      const [result] = await pool.query(
        'INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)',
        [userData.nombre, userData.email, hashedPassword, userData.rol || 'usuario']
      );
      
      return { id: result.insertId, ...userData, password: undefined };
    } catch (error) {
      console.error('Error al crear usuario:', error);
      throw error;
    }
  }

  // Actualizar usuario
  static async update(id, userData) {
    try {
      let query = 'UPDATE usuarios SET ';
      const values = [];
      
      if (userData.nombre) {
        query += 'nombre = ?, ';
        values.push(userData.nombre);
      }
      
      if (userData.email) {
        query += 'email = ?, ';
        values.push(userData.email);
      }
      
      if (userData.password) {
        query += 'password = ?, ';
        const hashedPassword = await bcrypt.hash(userData.password, 10);
        values.push(hashedPassword);
      }
      
      if (userData.rol) {
        query += 'rol = ?, ';
        values.push(userData.rol);
      }
      
      // Eliminar la última coma y espacio
      query = query.slice(0, -2);
      
      query += ' WHERE id = ?';
      values.push(id);
      
      const [result] = await pool.query(query, values);
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error al actualizar usuario:', error);
      throw error;
    }
  }

  // Eliminar usuario
  static async delete(id) {
    try {
      const [result] = await pool.query(
        'DELETE FROM usuarios WHERE id = ?',
        [id]
      );
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error al eliminar usuario:', error);
      throw error;
    }
  }

  // Verificar credenciales
  static async verifyCredentials(email, password) {
    try {
      const user = await this.getByEmail(email);
      
      if (!user) {
        return null;
      }
      
      const isPasswordValid = await bcrypt.compare(password, user.password);
      
      if (!isPasswordValid) {
        return null;
      }
      
      // No devolver la contraseña
      const { password: _, ...userWithoutPassword } = user;
      return userWithoutPassword;
    } catch (error) {
      console.error('Error al verificar credenciales:', error);
      throw error;
    }
  }
}

module.exports = Usuario;
