// Modelo para la gestión de documentos
const { pool } = require('../config/database');

class Documento {
  // Obtener todos los documentos de un contrato
  static async getAllByContrato(contratoId) {
    try {
      const [rows] = await pool.query(
        `SELECT d.*, u.nombre as usuario_nombre 
         FROM documentos d
         JOIN usuarios u ON d.usuario_id = u.id
         WHERE d.contrato_id = ?
         ORDER BY d.fecha_creacion DESC`,
        [contratoId]
      );
      return rows;
    } catch (error) {
      console.error('Error al obtener documentos:', error);
      throw error;
    }
  }

  // Obtener documento por ID
  static async getById(id) {
    try {
      const [rows] = await pool.query(
        `SELECT d.*, u.nombre as usuario_nombre 
         FROM documentos d
         JOIN usuarios u ON d.usuario_id = u.id
         WHERE d.id = ?`,
        [id]
      );
      return rows[0];
    } catch (error) {
      console.error('Error al obtener documento por ID:', error);
      throw error;
    }
  }

  // Crear nuevo documento
  static async create(documentoData) {
    try {
      const [result] = await pool.query(
        `INSERT INTO documentos (
          contrato_id, usuario_id, nombre, descripcion, url, tipo
        ) VALUES (?, ?, ?, ?, ?, ?)`,
        [
          documentoData.contrato_id,
          documentoData.usuario_id,
          documentoData.nombre,
          documentoData.descripcion || null,
          documentoData.url,
          documentoData.tipo || null
        ]
      );
      
      return { id: result.insertId, ...documentoData };
    } catch (error) {
      console.error('Error al crear documento:', error);
      throw error;
    }
  }

  // Actualizar documento
  static async update(id, documentoData) {
    try {
      const [result] = await pool.query(
        `UPDATE documentos SET 
          nombre = ?, 
          descripcion = ?,
          url = ?,
          tipo = ?
         WHERE id = ?`,
        [
          documentoData.nombre,
          documentoData.descripcion || null,
          documentoData.url,
          documentoData.tipo || null,
          id
        ]
      );
      
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error al actualizar documento:', error);
      throw error;
    }
  }

  // Eliminar documento
  static async delete(id) {
    try {
      const [result] = await pool.query(
        'DELETE FROM documentos WHERE id = ?',
        [id]
      );
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error al eliminar documento:', error);
      throw error;
    }
  }

  // Buscar documentos por nombre o descripción
  static async search(searchTerm) {
    try {
      const [rows] = await pool.query(
        `SELECT d.*, c.numero_contrato, u.nombre as usuario_nombre 
         FROM documentos d
         JOIN contratos c ON d.contrato_id = c.id
         JOIN usuarios u ON d.usuario_id = u.id
         WHERE d.nombre LIKE ? OR d.descripcion LIKE ?
         ORDER BY d.fecha_creacion DESC`,
        [`%${searchTerm}%`, `%${searchTerm}%`]
      );
      return rows;
    } catch (error) {
      console.error('Error al buscar documentos:', error);
      throw error;
    }
  }
}

module.exports = Documento;
