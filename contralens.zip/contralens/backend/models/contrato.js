// Modelo para la gestión de contratos
const { pool } = require('../config/database');

class Contrato {
  // Obtener todos los contratos
  static async getAll(filters = {}) {
    try {
      let query = `
        SELECT c.*, u.nombre as usuario_nombre 
        FROM contratos c
        JOIN usuarios u ON c.usuario_id = u.id
        WHERE 1=1
      `;
      const values = [];
      
      // Aplicar filtros si existen
      if (filters.estado) {
        query += ' AND c.estado = ?';
        values.push(filters.estado);
      }
      
      if (filters.contratista) {
        query += ' AND c.nombre_contratista LIKE ?';
        values.push(`%${filters.contratista}%`);
      }
      
      if (filters.numero_contrato) {
        query += ' AND c.numero_contrato LIKE ?';
        values.push(`%${filters.numero_contrato}%`);
      }
      
      if (filters.fecha_inicio) {
        query += ' AND c.fecha_inicio >= ?';
        values.push(filters.fecha_inicio);
      }
      
      if (filters.fecha_final) {
        query += ' AND c.fecha_final <= ?';
        values.push(filters.fecha_final);
      }
      
      // Ordenar por fecha de creación descendente
      query += ' ORDER BY c.fecha_creacion DESC';
      
      const [rows] = await pool.query(query, values);
      return rows;
    } catch (error) {
      console.error('Error al obtener contratos:', error);
      throw error;
    }
  }

  // Obtener contrato por ID
  static async getById(id) {
    try {
      const [rows] = await pool.query(
        `SELECT c.*, u.nombre as usuario_nombre 
         FROM contratos c
         JOIN usuarios u ON c.usuario_id = u.id
         WHERE c.id = ?`,
        [id]
      );
      return rows[0];
    } catch (error) {
      console.error('Error al obtener contrato por ID:', error);
      throw error;
    }
  }

  // Crear nuevo contrato
  static async create(contratoData) {
    try {
      const [result] = await pool.query(
        `INSERT INTO contratos (
          convenio, numero_contrato, nombre_contratista, representante_legal, 
          nit_empresa, objeto_contrato, valor_inicial, valor_final, 
          fecha_suscripcion, fecha_inicio, fecha_final, estado, usuario_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          contratoData.convenio,
          contratoData.numero_contrato,
          contratoData.nombre_contratista,
          contratoData.representante_legal,
          contratoData.nit_empresa,
          contratoData.objeto_contrato,
          contratoData.valor_inicial,
          contratoData.valor_final,
          contratoData.fecha_suscripcion,
          contratoData.fecha_inicio,
          contratoData.fecha_final,
          contratoData.estado || 'activo',
          contratoData.usuario_id
        ]
      );
      
      return { id: result.insertId, ...contratoData };
    } catch (error) {
      console.error('Error al crear contrato:', error);
      throw error;
    }
  }

  // Actualizar contrato
  static async update(id, contratoData) {
    try {
      let query = 'UPDATE contratos SET ';
      const values = [];
      const fields = [
        'convenio', 'numero_contrato', 'nombre_contratista', 'representante_legal',
        'nit_empresa', 'objeto_contrato', 'valor_inicial', 'valor_final',
        'fecha_suscripcion', 'fecha_inicio', 'fecha_final', 'estado'
      ];
      
      // Construir la consulta dinámicamente
      const updates = [];
      
      fields.forEach(field => {
        if (contratoData[field] !== undefined) {
          updates.push(`${field} = ?`);
          values.push(contratoData[field]);
        }
      });
      
      query += updates.join(', ');
      query += ' WHERE id = ?';
      values.push(id);
      
      const [result] = await pool.query(query, values);
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error al actualizar contrato:', error);
      throw error;
    }
  }

  // Eliminar contrato
  static async delete(id) {
    try {
      const [result] = await pool.query(
        'DELETE FROM contratos WHERE id = ?',
        [id]
      );
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error al eliminar contrato:', error);
      throw error;
    }
  }

  // Obtener estadísticas para el dashboard
  static async getStats() {
    try {
      // Total de contratos por estado
      const [estadosStats] = await pool.query(
        'SELECT estado, COUNT(*) as total FROM contratos GROUP BY estado'
      );
      
      // Valor total de contratos
      const [valorTotal] = await pool.query(
        'SELECT SUM(valor_final) as total FROM contratos'
      );
      
      // Contratos próximos a vencer (en los próximos 30 días)
      const [proximosVencer] = await pool.query(
        `SELECT * FROM contratos 
         WHERE fecha_final BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
         ORDER BY fecha_final ASC`
      );
      
      // Contratos recientes (últimos 5)
      const [recientes] = await pool.query(
        'SELECT * FROM contratos ORDER BY fecha_creacion DESC LIMIT 5'
      );
      
      return {
        porEstado: estadosStats,
        valorTotal: valorTotal[0].total,
        proximosVencer,
        recientes
      };
    } catch (error) {
      console.error('Error al obtener estadísticas:', error);
      throw error;
    }
  }
}

module.exports = Contrato;
