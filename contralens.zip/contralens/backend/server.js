// Actualizar server.js para incluir todas las rutas
const express = require('express');
const cors = require('cors');
const { testConnection } = require('./config/database');
require('dotenv').config();

// Importar rutas
const authRoutes = require('./routes/auth');
const contratosRoutes = require('./routes/contratos');
const supervisionRoutes = require('./routes/supervision');
const documentosRoutes = require('./routes/documentos');

// Inicializar la aplicación Express
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Ruta de prueba
app.get('/', (req, res) => {
  res.json({ message: 'API de ContraLens funcionando correctamente' });
});

// Implementar rutas
app.use('/api/auth', authRoutes);
app.use('/api/contratos', contratosRoutes);
app.use('/api/supervision', supervisionRoutes);
app.use('/api/documentos', documentosRoutes);

// Añade estos endpoints justo antes de la definición de app.listen()

// Endpoint de verificación de salud
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// Endpoint de verificación de base de datos
app.get('/api/health/db', async (req, res) => {
  try {
    const [result] = await pool.query('SELECT 1 as dbCheck');
    res.json({
      status: 'ok',
      dbConnection: true,
      result: result
    });
  } catch (error) {
    console.error('Error de verificación de DB:', error);
    res.status(500).json({
      status: 'error',
      message: error.message
    });
  }
});

// También soportar POST para la misma ruta (a veces ayuda con CORS)
app.post('/api/health/db', async (req, res) => {
  try {
    const [result] = await pool.query('SELECT 1 as dbCheck');
    res.json({
      status: 'ok',
      dbConnection: true,
      result: result
    });
  } catch (error) {
    console.error('Error de verificación de DB (POST):', error);
    res.status(500).json({
      status: 'error',
      message: error.message
    });
  }
});

// Ruta raíz para verificar que el servidor esté respondiendo
app.get('/', (req, res) => {
  res.send('ContraLens API está funcionando correctamente');
});

// Iniciar el servidor
app.listen(PORT, async () => {
  console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
  
  // Probar conexión a la base de datos
  await testConnection();
});

module.exports = app;
