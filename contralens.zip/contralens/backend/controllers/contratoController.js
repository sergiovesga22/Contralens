// Controlador de contratos
const Contrato = require('../models/contrato');

// Obtener todos los contratos
exports.getAll = async (req, res) => {
  try {
    // Extraer filtros de la consulta
    const { estado, contratista, numero_contrato, fecha_inicio, fecha_final } = req.query;
    
    const filters = {
      estado,
      contratista,
      numero_contrato,
      fecha_inicio,
      fecha_final
    };
    
    const contratos = await Contrato.getAll(filters);
    
    res.json({
      success: true,
      data: contratos
    });
  } catch (error) {
    console.error('Error al obtener contratos:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Obtener contrato por ID
exports.getById = async (req, res) => {
  try {
    const contratoId = req.params.id;
    
    const contrato = await Contrato.getById(contratoId);
    
    if (!contrato) {
      return res.status(404).json({ 
        success: false, 
        message: 'Contrato no encontrado' 
      });
    }
    
    res.json({
      success: true,
      data: contrato
    });
  } catch (error) {
    console.error('Error al obtener contrato:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Crear nuevo contrato
exports.create = async (req, res) => {
  try {
    const contratoData = {
      ...req.body,
      usuario_id: req.user.id // Obtener el ID del usuario autenticado
    };
    
    // Validar datos de entrada
    if (!contratoData.numero_contrato || !contratoData.nombre_contratista || 
        !contratoData.objeto_contrato || !contratoData.valor_inicial || 
        !contratoData.fecha_inicio || !contratoData.fecha_final) {
      return res.status(400).json({ 
        success: false, 
        message: 'Faltan campos requeridos' 
      });
    }
    
    // Crear nuevo contrato
    const newContrato = await Contrato.create(contratoData);
    
    res.status(201).json({
      success: true,
      message: 'Contrato creado exitosamente',
      data: newContrato
    });
  } catch (error) {
    console.error('Error al crear contrato:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Actualizar contrato
exports.update = async (req, res) => {
  try {
    const contratoId = req.params.id;
    const contratoData = req.body;
    
    // Verificar si el contrato existe
    const contrato = await Contrato.getById(contratoId);
    
    if (!contrato) {
      return res.status(404).json({ 
        success: false, 
        message: 'Contrato no encontrado' 
      });
    }
    
    // Actualizar contrato
    const updated = await Contrato.update(contratoId, contratoData);
    
    if (!updated) {
      return res.status(400).json({ 
        success: false, 
        message: 'No se pudo actualizar el contrato' 
      });
    }
    
    res.json({
      success: true,
      message: 'Contrato actualizado exitosamente'
    });
  } catch (error) {
    console.error('Error al actualizar contrato:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Eliminar contrato
exports.delete = async (req, res) => {
  try {
    const contratoId = req.params.id;
    
    // Verificar si el contrato existe
    const contrato = await Contrato.getById(contratoId);
    
    if (!contrato) {
      return res.status(404).json({ 
        success: false, 
        message: 'Contrato no encontrado' 
      });
    }
    
    // Eliminar contrato
    const deleted = await Contrato.delete(contratoId);
    
    if (!deleted) {
      return res.status(400).json({ 
        success: false, 
        message: 'No se pudo eliminar el contrato' 
      });
    }
    
    res.json({
      success: true,
      message: 'Contrato eliminado exitosamente'
    });
  } catch (error) {
    console.error('Error al eliminar contrato:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Obtener estadísticas para el dashboard
exports.getStats = async (req, res) => {
  try {
    const stats = await Contrato.getStats();
    
    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    console.error('Error al obtener estadísticas:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};
