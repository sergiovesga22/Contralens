// Controlador de supervisión
const Supervision = require('../models/supervision');

// Obtener todos los registros de supervisión de un contrato
exports.getAllByContrato = async (req, res) => {
  try {
    const contratoId = req.params.contratoId;
    
    const registros = await Supervision.getAllByContrato(contratoId);
    
    res.json({
      success: true,
      data: registros
    });
  } catch (error) {
    console.error('Error al obtener registros de supervisión:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Obtener registro de supervisión por ID
exports.getById = async (req, res) => {
  try {
    const supervisionId = req.params.id;
    
    const supervision = await Supervision.getById(supervisionId);
    
    if (!supervision) {
      return res.status(404).json({ 
        success: false, 
        message: 'Registro de supervisión no encontrado' 
      });
    }
    
    res.json({
      success: true,
      data: supervision
    });
  } catch (error) {
    console.error('Error al obtener registro de supervisión:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Crear nuevo registro de supervisión
exports.create = async (req, res) => {
  try {
    const supervisionData = {
      ...req.body,
      usuario_id: req.user.id // Obtener el ID del usuario autenticado
    };
    
    // Validar datos de entrada
    if (!supervisionData.contrato_id || !supervisionData.observaciones) {
      return res.status(400).json({ 
        success: false, 
        message: 'Contrato ID y observaciones son requeridos' 
      });
    }
    
    // Crear nuevo registro de supervisión
    const newSupervision = await Supervision.create(supervisionData);
    
    res.status(201).json({
      success: true,
      message: 'Registro de supervisión creado exitosamente',
      data: newSupervision
    });
  } catch (error) {
    console.error('Error al crear registro de supervisión:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Actualizar registro de supervisión
exports.update = async (req, res) => {
  try {
    const supervisionId = req.params.id;
    const supervisionData = req.body;
    
    // Verificar si el registro de supervisión existe
    const supervision = await Supervision.getById(supervisionId);
    
    if (!supervision) {
      return res.status(404).json({ 
        success: false, 
        message: 'Registro de supervisión no encontrado' 
      });
    }
    
    // Actualizar registro de supervisión
    const updated = await Supervision.update(supervisionId, supervisionData);
    
    if (!updated) {
      return res.status(400).json({ 
        success: false, 
        message: 'No se pudo actualizar el registro de supervisión' 
      });
    }
    
    res.json({
      success: true,
      message: 'Registro de supervisión actualizado exitosamente'
    });
  } catch (error) {
    console.error('Error al actualizar registro de supervisión:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Eliminar registro de supervisión
exports.delete = async (req, res) => {
  try {
    const supervisionId = req.params.id;
    
    // Verificar si el registro de supervisión existe
    const supervision = await Supervision.getById(supervisionId);
    
    if (!supervision) {
      return res.status(404).json({ 
        success: false, 
        message: 'Registro de supervisión no encontrado' 
      });
    }
    
    // Eliminar registro de supervisión
    const deleted = await Supervision.delete(supervisionId);
    
    if (!deleted) {
      return res.status(400).json({ 
        success: false, 
        message: 'No se pudo eliminar el registro de supervisión' 
      });
    }
    
    res.json({
      success: true,
      message: 'Registro de supervisión eliminado exitosamente'
    });
  } catch (error) {
    console.error('Error al eliminar registro de supervisión:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Obtener alertas de supervisión con prioridad alta
exports.getPriorityAlerts = async (req, res) => {
  try {
    const alerts = await Supervision.getPriorityAlerts();
    
    res.json({
      success: true,
      data: alerts
    });
  } catch (error) {
    console.error('Error al obtener alertas de supervisión:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};
