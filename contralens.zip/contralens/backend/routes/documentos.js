// Rutas de documentos
const express = require('express');
const router = express.Router();
const documentoController = require('../controllers/documentoController');
const { verifyToken, isEditorOrAdmin } = require('../middleware/auth');

// Aplicar middleware de autenticación a todas las rutas
router.use(verifyToken);

// Rutas de lectura (accesibles para todos los usuarios autenticados)
router.get('/contrato/:contratoId', documentoController.getAllByContrato);
router.get('/search', documentoController.search);
router.get('/:id', documentoController.getById);

// Rutas de escritura (solo para editores y administradores)
router.post('/', isEditorOrAdmin, documentoController.create);
router.put('/:id', isEditorOrAdmin, documentoController.update);
router.delete('/:id', isEditorOrAdmin, documentoController.delete);

module.exports = router;
