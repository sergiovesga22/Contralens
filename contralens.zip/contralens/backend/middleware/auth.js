// Middleware de autenticación
const jwt = require('jsonwebtoken');
require('dotenv').config();

// Verificar token JWT
exports.verifyToken = (req, res, next) => {
  try {
    // Obtener token del encabezado Authorization
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ 
        success: false, 
        message: 'Token no proporcionado' 
      });
    }
    
    const token = authHeader.split(' ')[1];
    
    // Verificar token
    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
      if (err) {
        return res.status(401).json({ 
          success: false, 
          message: 'Token inválido o expirado' 
        });
      }
      
      // Guardar datos del usuario en el objeto de solicitud
      req.user = decoded;
      next();
    });
  } catch (error) {
    console.error('Error en verificación de token:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Verificar rol de administrador
exports.isAdmin = (req, res, next) => {
  if (req.user && req.user.rol === 'admin') {
    next();
  } else {
    res.status(403).json({ 
      success: false, 
      message: 'Acceso denegado. Se requiere rol de administrador' 
    });
  }
};

// Verificar rol de editor o administrador
exports.isEditorOrAdmin = (req, res, next) => {
  if (req.user && (req.user.rol === 'editor' || req.user.rol === 'admin')) {
    next();
  } else {
    res.status(403).json({ 
      success: false, 
      message: 'Acceso denegado. Se requiere rol de editor o administrador' 
    });
  }
};
