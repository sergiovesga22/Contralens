/**
 * reportes.js
 * Script para la funcionalidad de reportes
 */

// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
  // Referencias a elementos del DOM
  const btnGenerarReporte = document.getElementById('btn-generar-reporte');
  const btnExportarExcel = document.getElementById('btn-exportar-excel');
  const btnExportarPdf = document.getElementById('btn-exportar-pdf');
  const btnGuardarReporte = document.getElementById('btn-guardar-reporte');
  const btnNuevoReporte = document.getElementById('btn-nuevo-reporte');
  const btnLimpiarReporte = document.getElementById('btn-limpiar-reporte');
  const tablaReporte = document.getElementById('tabla-reporte');
  const reportePaginacion = document.getElementById('reporte-paginacion');
  
  // Elementos de resumen
  const reporteTotalContratos = document.getElementById('reporte-total-contratos');
  const reporteValorTotal = document.getElementById('reporte-valor-total');
  const reportePromedioValor = document.getElementById('reporte-promedio-valor');
  const reporteDuracionPromedio = document.getElementById('reporte-duracion-promedio');
  
  // Gráfico
  const reporteGrafico = document.getElementById('reporte-grafico');
  let reporteGraficoInstance = null;
  
  // Estado interno
  let reporteActual = {
    tipo: '',
    filtros: {},
    resultados: [],
    pagina: 1,
    porPagina: 10,
    totalPaginas: 1
  };
  
  // Inicializar eventos
  function inicializarEventos() {
    // Generar reporte
    btnGenerarReporte.addEventListener('click', generarReporte);
    
    // Exportar reporte
    btnExportarExcel.addEventListener('click', exportarExcel);
    btnExportarPdf.addEventListener('click', exportarPdf);
    
    // Guardar reporte
    btnGuardarReporte.addEventListener('click', guardarReporte);
    
    // Nuevo reporte
    btnNuevoReporte.addEventListener('click', nuevoReporte);
    
    // Limpiar filtros
    btnLimpiarReporte.addEventListener('click', limpiarFiltros);
  }
  
  // Generar reporte
  async function generarReporte() {
    // Obtener valores de los filtros
    const tipo = document.getElementById('reporte-tipo').value;
    const fechaInicio = document.getElementById('reporte-fecha-inicio').value;
    const fechaFin = document.getElementById('reporte-fecha-fin').value;
    const estado = document.getElementById('reporte-estado').value;
    const contratista = document.getElementById('reporte-contratista').value;
    const valorMin = document.getElementById('reporte-valor-min').value;
    
    // Guardar filtros en el estado
    reporteActual.tipo = tipo;
    reporteActual.filtros = {
      fecha_inicio: fechaInicio,
      fecha_final: fechaFin,
      estado: estado,
      contratista: contratista,
      valor_min: valorMin
    };
    
    // Obtener datos según el tipo de reporte
    try {
      let response;
      
      if (tipo === 'contratos') {
        response = await ApiService.getContratos(reporteActual.filtros);
      } else if (tipo === 'supervision') {
        // Aquí se implementaría la lógica para reportes de supervisión
        // Por ahora, usamos los mismos datos de contratos
        response = await ApiService.getContratos(reporteActual.filtros);
      } else if (tipo === 'financiero') {
        // Aquí se implementaría la lógica para reportes financieros
        // Por ahora, usamos los mismos datos de contratos
        response = await ApiService.getContratos(reporteActual.filtros);
      }
      
      if (response && response.success) {
        reporteActual.resultados = response.data;
        reporteActual.pagina = 1;
        reporteActual.totalPaginas = Math.ceil(reporteActual.resultados.length / reporteActual.porPagina);
        
        // Actualizar UI
        renderizarTablaReporte();
        actualizarResumenReporte();
        actualizarGraficoReporte();
      }
    } catch (error) {
      console.error('Error al generar reporte:', error);
      ApiService.mostrarError('Error al generar reporte');
    }
  }
  
  // Renderizar tabla de reporte
  function renderizarTablaReporte() {
    const tbody = tablaReporte.querySelector('tbody');
    tbody.innerHTML = '';
    
    if (reporteActual.resultados.length === 0) {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td colspan="8" class="text-center">No hay datos disponibles</td>`;
      tbody.appendChild(tr);
      
      // Ocultar paginación
      reportePaginacion.style.display = 'none';
      return;
    }
    
    // Calcular índices para paginación
    const inicio = (reporteActual.pagina - 1) * reporteActual.porPagina;
    const fin = Math.min(inicio + reporteActual.porPagina, reporteActual.resultados.length);
    const resultadosPagina = reporteActual.resultados.slice(inicio, fin);
    
    // Mostrar paginación si hay más de una página
    if (reporteActual.totalPaginas > 1) {
      reportePaginacion.style.display = 'flex';
      renderizarPaginacion();
    } else {
      reportePaginacion.style.display = 'none';
    }
    
    // Renderizar filas
    resultadosPagina.forEach(contrato => {
      const tr = document.createElement('tr');
      
      // Formatear valores para mostrar
      const valorInicial = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP' }).format(contrato.valor_inicial);
      const valorFinal = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP' }).format(contrato.valor_final);
      
      // Determinar clase de estado
      let estadoClass = '';
      switch (contrato.estado) {
        case 'activo':
          estadoClass = 'text-success';
          break;
        case 'revision':
          estadoClass = 'text-warning';
          break;
        case 'expirado':
          estadoClass = 'text-danger';
          break;
      }
      
      tr.innerHTML = `
        <td>${contrato.numero_contrato}</td>
        <td>${contrato.nombre_contratista}</td>
        <td>${contrato.objeto_contrato.substring(0, 50)}${contrato.objeto_contrato.length > 50 ? '...' : ''}</td>
        <td>${valorInicial}</td>
        <td>${valorFinal}</td>
        <td>${formatearFecha(contrato.fecha_inicio)}</td>
        <td>${formatearFecha(contrato.fecha_final)}</td>
        <td class="${estadoClass}">${capitalizarPrimeraLetra(contrato.estado)}</td>
      `;
      
      tbody.appendChild(tr);
    });
  }
  
  // Renderizar paginación
  function renderizarPaginacion() {
    reportePaginacion.innerHTML = '';
    
    // Botón anterior
    const liAnterior = document.createElement('li');
    liAnterior.className = 'page-item';
    liAnterior.innerHTML = `<a class="page-link" href="#">&laquo;</a>`;
    liAnterior.addEventListener('click', (e) => {
      e.preventDefault();
      if (reporteActual.pagina > 1) {
        reporteActual.pagina--;
        renderizarTablaReporte();
      }
    });
    reportePaginacion.appendChild(liAnterior);
    
    // Páginas
    for (let i = 1; i <= reporteActual.totalPaginas; i++) {
      const li = document.createElement('li');
      li.className = 'page-item';
      const a = document.createElement('a');
      a.className = `page-link ${i === reporteActual.pagina ? 'active' : ''}`;
      a.href = '#';
      a.textContent = i;
      a.addEventListener('click', (e) => {
        e.preventDefault();
        reporteActual.pagina = i;
        renderizarTablaReporte();
      });
      li.appendChild(a);
      reportePaginacion.appendChild(li);
    }
    
    // Botón siguiente
    const liSiguiente = document.createElement('li');
    liSiguiente.className = 'page-item';
    liSiguiente.innerHTML = `<a class="page-link" href="#">&raquo;</a>`;
    liSiguiente.addEventListener('click', (e) => {
      e.preventDefault();
      if (reporteActual.pagina < reporteActual.totalPaginas) {
        reporteActual.pagina++;
        renderizarTablaReporte();
      }
    });
    reportePaginacion.appendChild(liSiguiente);
  }
  
  // Actualizar resumen del reporte
  function actualizarResumenReporte() {
    if (reporteActual.resultados.length === 0) {
      reporteTotalContratos.textContent = '0';
      reporteValorTotal.textContent = '$0';
      reportePromedioValor.textContent = '$0';
      reporteDuracionPromedio.textContent = '0';
      return;
    }
    
    // Total de contratos
    reporteTotalContratos.textContent = reporteActual.resultados.length;
    
    // Valor total
    const valorTotal = reporteActual.resultados.reduce((sum, contrato) => sum + contrato.valor_final, 0);
    reporteValorTotal.textContent = new Intl.NumberFormat('es-CO', { 
      style: 'currency', 
      currency: 'COP',
      maximumFractionDigits: 0
    }).format(valorTotal);
    
    // Valor promedio
    const valorPromedio = valorTotal / reporteActual.resultados.length;
    reportePromedioValor.textContent = new Intl.NumberFormat('es-CO', { 
      style: 'currency', 
      currency: 'COP',
      maximumFractionDigits: 0
    }).format(valorPromedio);
    
    // Duración promedio
    let duracionTotal = 0;
    reporteActual.resultados.forEach(contrato => {
      const fechaInicio = new Date(contrato.fecha_inicio);
      const fechaFinal = new Date(contrato.fecha_final);
      const duracion = Math.ceil((fechaFinal - fechaInicio) / (1000 * 60 * 60 * 24));
      duracionTotal += duracion;
    });
    const duracionPromedio = Math.round(duracionTotal / reporteActual.resultados.length);
    reporteDuracionPromedio.textContent = duracionPromedio;
  }
  
  // Actualizar gráfico del reporte
  function actualizarGraficoReporte() {
    if (reporteActual.resultados.length === 0) {
      if (reporteGraficoInstance) {
        reporteGraficoInstance.destroy();
        reporteGraficoInstance = null;
      }
      return;
    }
    
    // Destruir gráfico existente si hay uno
    if (reporteGraficoInstance) {
      reporteGraficoInstance.destroy();
    }
    
    // Preparar datos según el tipo de reporte
    let chartData;
    
    if (reporteActual.tipo === 'contratos') {
      // Agrupar por estado
      const porEstado = {};
      reporteActual.resultados.forEach(contrato => {
        if (!porEstado[contrato.estado]) {
          porEstado[contrato.estado] = 0;
        }
        porEstado[contrato.estado]++;
      });
      
      // Preparar datos para el gráfico
      const labels = Object.keys(porEstado).map(estado => capitalizarPrimeraLetra(estado));
      const data = Object.values(porEstado);
      const backgroundColor = labels.map(label => {
        switch (label.toLowerCase()) {
          case 'activo': return '#2ecc71';
          case 'revision': return '#f39c12';
          case 'expirado': return '#e74c3c';
          default: return '#3498db';
        }
      });
      
      chartData = {
        type: 'pie',
        data: {
          labels: labels,
          datasets: [{
            data: data,
            backgroundColor: backgroundColor,
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'right',
            },
            title: {
              display: true,
              text: 'Distribución de Contratos por Estado'
            }
          }
        }
      };
    } else if (reporteActual.tipo === 'financiero') {
      // Ordenar contratos por valor
      const contratosOrdenados = [...reporteActual.resultados].sort((a, b) => b.valor_final - a.valor_final);
      
      // Tomar los 5 contratos con mayor valor
      const top5 = contratosOrdenados.slice(0, 5);
      
      // Preparar datos para el gráfico
      const labels = top5.map(contrato => contrato.numero_contrato);
      const data = top5.map(contrato => contrato.valor_final);
      
      chartData = {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [{
            label: 'Valor Final',
            data: data,
            backgroundColor: '#3498db',
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: 'Top 5 Contratos por Valor'
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                callback: function(value) {
                  return new Intl.NumberFormat('es-CO', { 
                    style: 'currency', 
                    currency: 'COP',
                    notation: 'compact',
                    compactDisplay: 'short'
                  }).format(value);
                }
              }
            }
          }
        }
      };
    } else {
      // Tipo supervisión u otro
      // Agrupar por mes
      const porMes = {};
      reporteActual.resultados.forEach(contrato => {
        const fecha = new Date(contrato.fecha_inicio);
        const mes = fecha.toLocaleString('es-ES', { month: 'long' });
        if (!porMes[mes]) {
          porMes[mes] = 0;
        }
        porMes[mes]++;
      });
      
      // Preparar datos para el gráfico
      const labels = Object.keys(porMes);
      const data = Object.values(porMes);
      
      chartData = {
        type: 'line',
        data: {
          labels: labels,
          datasets: [{
            label: 'Contratos por Mes',
            data: data,
            borderColor: '#3498db',
            backgroundColor: 'rgba(52, 152, 219, 0.2)',
            borderWidth: 2,
            fill: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: true,
              text: 'Distribución de Contratos por Mes'
            }
          },
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      };
    }
    
    // Crear nuevo gráfico
    reporteGraficoInstance = new Chart(reporteGrafico, chartData);
  }
  
  // Exportar a Excel
  function exportarExcel() {
    if (reporteActual.resultados.length === 0) {
      ApiService.mostrarError('No hay datos para exportar');
      return;
    }
    
    // En una implementación real, se enviaría una petición al servidor
    // para generar el archivo Excel. Por ahora, simulamos la descarga.
    alert('Exportando a Excel... (Funcionalidad simulada)');
  }
  
  // Exportar a PDF
  function exportarPdf() {
    if (reporteActual.resultados.length === 0) {
      ApiService.mostrarError('No hay datos para exportar');
      return;
    }
    
    // En una implementación real, se enviaría una petición al servidor
    // para generar el archivo PDF. Por ahora, simulamos la descarga.
    alert('Exportando a PDF... (Funcionalidad simulada)');
  }
  
  // Guardar reporte
  function guardarReporte() {
    if (reporteActual.resultados.length === 0) {
      ApiService.mostrarError('No hay datos para guardar');
      return;
    }
    
    const nombreReporte = prompt('Ingrese un nombre para el reporte:');
    
    if (!nombreReporte) {
      return;
    }
    
    // En una implementación real, se guardaría en la base de datos
    // Por ahora, simulamos el guardado en localStorage
    const reportesGuardados = JSON.parse(localStorage.getItem('reportesGuardados') || '[]');
    
    const nuevoReporte = {
      id: Date.now(),
      nombre: nombreReporte,
      fecha: new Date().toISOString(),
      tipo: reporteActual.tipo,
      filtros: reporteActual.filtros,
      totalResultados: reporteActual.resultados.length
    };
    
    reportesGuardados.push(nuevoReporte);
    localStorage.setItem('reportesGuardados', JSON.stringify(reportesGuardados));
    
    ApiService.mostrarExito('Reporte guardado exitosamente');
    cargarReportesGuardados();
  }
  
  // Cargar reportes guardados
  function cargarReportesGuardados() {
    const listaReportes = document.getElementById('lista-reportes-guardados');
    listaReportes.innerHTML = '';
    
    const reportesGuardados = JSON.parse(localStorage.getItem('reportesGuardados') || '[]');
    
    if (reportesGuardados.length === 0) {
      listaReportes.innerHTML = '<p class="text-center">No hay reportes guardados</p>';
      return;
    }
    
    reportesGuardados.forEach(reporte => {
      const reporteItem = document.createElement('div');
      reporteItem.className = 'saved-report-item';
      
      reporteItem.innerHTML = `
        <div class="saved-report-info">
          <div class="saved-report-title">${reporte.nombre}</div>
          <div class="saved-report-date">
            ${formatearFecha(reporte.fecha)} | 
            Tipo: ${capitalizarPrimeraLetra(reporte.tipo)} | 
            Resultados: ${reporte.totalResultados}
          </div>
        </div>
        <div class="saved-report-actions">
          <button class="btn btn-sm btn-outline" data-id="${reporte.id}" data-action="cargar">
            <i class="fas fa-folder-open"></i> Cargar
          </button>
          <button class="btn btn-sm btn-danger" data-id="${reporte.id}" data-action="eliminar">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      `;
      
      listaReportes.appendChild(reporteItem);
      
      // Añadir eventos a los botones
      const btnCargar = reporteItem.querySelector('[data-action="cargar"]');
      const btnEliminar = reporteItem.querySelector('[data-action="eliminar"]');
      
      btnCargar.addEventListener('click', () => cargarReporteGuardado(reporte.id));
      btnEliminar.addEventListener('click', () => eliminarReporteGuardado(reporte.id));
    });
  }
  
  // Cargar un reporte guardado
  function cargarReporteGuardado(id) {
    const reportesGuardados = JSON.parse(localStorage.getItem('reportesGuardados') || '[]');
    const reporte = reportesGuardados.find(r => r.id === id);
    
    if (!reporte) {
      ApiService.mostrarError('Reporte no encontrado');
      return;
    }
    
    // Establecer filtros
    document.getElementById('reporte-tipo').value = reporte.tipo;
    
    if (reporte.filtros.fecha_inicio) {
      document.getElementById('reporte-fecha-inicio').value = reporte.filtros.fecha_inicio;
    }
    
    if (reporte.filtros.fecha_final) {
      document.getElementById('reporte-fecha-fin').value = reporte.filtros.fecha_final;
    }
    
    if (reporte.filtros.estado) {
      document.getElementById('reporte-estado').value = reporte.filtros.estado;
    }
    
    if (reporte.filtros.contratista) {
      document.getElementById('reporte-contratista').value = reporte.filtros.contratista;
    }
    
    if (reporte.filtros.valor_min) {
      document.getElementById('reporte-valor-min').value = reporte.filtros.valor_min;
    }
    
    // Generar reporte
    generarReporte();
  }
  
  // Eliminar un reporte guardado
  function eliminarReporteGuardado(id) {
    if (!confirm('¿Está seguro de eliminar este reporte guardado?')) {
      return;
    }
    
    const reportesGuardados = JSON.parse(localStorage.getItem('reportesGuardados') || '[]');
    const nuevosReportes = reportesGuardados.filter(r => r.id !== id);
    
    localStorage.setItem('reportesGuardados', JSON.stringify(nuevosReportes));
    
    ApiService.mostrarExito('Reporte eliminado exitosamente');
    cargarReportesGuardados();
  }
  
  // Nuevo reporte (limpiar todo)
  function nuevoReporte() {
    limpiarFiltros();
    
    // Limpiar resultados
    reporteActual.resultados = [];
    reporteActual.pagina = 1;
    reporteActual.totalPaginas = 1;
    
    // Actualizar UI
    renderizarTablaReporte();
    actualizarResumenReporte();
    
    // Destruir gráfico si existe
    if (reporteGraficoInstance) {
      reporteGraficoInstance.destroy();
      reporteGraficoInstance = null;
    }
  }
  
  // Limpiar filtros
  function limpiarFiltros() {
    document.getElementById('reporte-fecha-inicio').value = '';
    document.getElementById('reporte-fecha-fin').value = '';
    document.getElementById('reporte-estado').value = '';
    document.getElementById('reporte-contratista').value = '';
    document.getElementById('reporte-valor-min').value = '';
  }
  
  // Formatear fecha
  function formatearFecha(fecha) {
    if (!fecha) return '';
    
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(fecha).toLocaleDateString('es-ES', options);
  }
  
  // Capitalizar primera letra
  function capitalizarPrimeraLetra(texto) {
    if (!texto) return '';
    return texto.charAt(0).toUpperCase() + texto.slice(1);
  }
  
  // Inicializar
  function init() {
    inicializarEventos();
    cargarReportesGuardados();
    nuevoReporte(); // Iniciar con un reporte vacío
  }
  
  // Iniciar cuando el DOM esté listo
  init();
});
