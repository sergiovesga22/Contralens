/**
 * codigo_supervision.js
 * Script principal que integra todos los módulos y maneja la navegación
 */

// Esperar a que el DOM esté completamente cargado
document.addEventListener('DOMContentLoaded', function() {
  // Verificar autenticación
  if (!securityModule.verificarAutenticacion()) {
    return; // Si no está autenticado, redirige a login
  }
  
  // Referencias a elementos del DOM
  const sidebarLinks = document.querySelectorAll('.sidebar-link');
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id$="-section"]');
  
  // Función para cambiar de sección
  function cambiarSeccion(seccionId) {
    // Ocultar todas las secciones
    sections.forEach(section => {
      section.style.display = 'none';
    });
    
    // Mostrar la sección seleccionada
    const seccionActiva = document.getElementById(`${seccionId}-section`);
    if (seccionActiva) {
      seccionActiva.style.display = 'block';
    }
    
    // Actualizar clases activas en sidebar
    sidebarLinks.forEach(link => {
      if (link.dataset.section === seccionId) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
    
    // Actualizar clases activas en nav
    navLinks.forEach(link => {
      if (link.id === `nav-${seccionId}`) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }
  
  // Eventos para links de sidebar
  sidebarLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const seccion = this.dataset.section;
      cambiarSeccion(seccion);
    });
  });
  
  // Eventos para links de nav
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const seccion = this.id.replace('nav-', '');
      cambiarSeccion(seccion);
    });
  });
  
  // Inicializar módulos
  securityModule.init();
  dashboardManager.init();
  contratosManager.init();
  
  // Iniciar en la sección dashboard
  cambiarSeccion('dashboard');
  
  // Funcionalidad para toggle del sidebar en móviles (se implementaría en una versión más completa)
  const btnToggleSidebar = document.querySelector('.btn-toggle-sidebar');
  if (btnToggleSidebar) {
    btnToggleSidebar.addEventListener('click', function() {
      document.querySelector('.sidebar').classList.toggle('active');
    });
  }
  
  // Funcionalidad para modo oscuro (se implementaría en una versión más completa)
  const btnToggleDarkMode = document.querySelector('.btn-toggle-dark-mode');
  if (btnToggleDarkMode) {
    btnToggleDarkMode.addEventListener('click', function() {
      document.body.classList.toggle('dark-mode');
      localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
    });
    
    // Aplicar modo oscuro si estaba activado
    if (localStorage.getItem('darkMode') === 'true') {
      document.body.classList.add('dark-mode');
    }
  }
});
