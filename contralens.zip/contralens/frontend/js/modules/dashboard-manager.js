/**
 * dashboard-manager.js
 * Módulo para gestionar la funcionalidad del dashboard
 */

class DashboardManager {
  constructor() {
    // Referencias a elementos del DOM
    this.totalContratos = document.getElementById('total-contratos');
    this.contratosActivos = document.getElementById('contratos-activos');
    this.contratosRevision = document.getElementById('contratos-revision');
    this.valorTotal = document.getElementById('valor-total');
    this.tablaProximosVencer = document.getElementById('tabla-proximos-vencer');
    this.chartEstados = document.getElementById('chart-estados');
    
    // Gráficos
    this.chartEstadosInstance = null;
    
    // Estado interno
    this.stats = null;
  }
  
  /**
   * Cargar estadísticas desde la API
   */
  async cargarEstadisticas() {
    try {
      const response = await ApiService.getStats();
      
      if (response && response.success) {
        this.stats = response.data;
        this.actualizarDashboard();
      }
    } catch (error) {
      console.error('Error al cargar estadísticas:', error);
    }
  }
  
  /**
   * Actualizar elementos del dashboard con los datos cargados
   */
  actualizarDashboard() {
    if (!this.stats) return;
    
    // Actualizar contadores
    let totalActivos = 0;
    let totalRevision = 0;
    
    this.stats.porEstado.forEach(estado => {
      if (estado.estado === 'activo') {
        totalActivos = estado.total;
      } else if (estado.estado === 'revision') {
        totalRevision = estado.total;
      }
    });
    
    const totalContratos = this.stats.porEstado.reduce((sum, estado) => sum + estado.total, 0);
    
    this.totalContratos.textContent = totalContratos;
    this.contratosActivos.textContent = totalActivos;
    this.contratosRevision.textContent = totalRevision;
    
    // Formatear valor total
    const valorFormateado = new Intl.NumberFormat('es-CO', { 
      style: 'currency', 
      currency: 'COP',
      maximumFractionDigits: 0
    }).format(this.stats.valorTotal);
    
    this.valorTotal.textContent = valorFormateado;
    
    // Actualizar tabla de contratos próximos a vencer
    this.actualizarTablaProximosVencer();
    
    // Actualizar gráficos
    this.actualizarGraficoEstados();
  }
  
  /**
   * Actualizar tabla de contratos próximos a vencer
   */
  actualizarTablaProximosVencer() {
    const tbody = this.tablaProximosVencer.querySelector('tbody');
    tbody.innerHTML = '';
    
    if (!this.stats.proximosVencer || this.stats.proximosVencer.length === 0) {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td colspan="6" class="text-center">No hay contratos próximos a vencer</td>`;
      tbody.appendChild(tr);
      return;
    }
    
    this.stats.proximosVencer.forEach(contrato => {
      const tr = document.createElement('tr');
      
      // Calcular días restantes
      const fechaFinal = new Date(contrato.fecha_final);
      const hoy = new Date();
      const diasRestantes = Math.ceil((fechaFinal - hoy) / (1000 * 60 * 60 * 24));
      
      // Determinar clase según días restantes
      let diasClass = '';
      if (diasRestantes <= 7) {
        diasClass = 'text-danger';
      } else if (diasRestantes <= 15) {
        diasClass = 'text-warning';
      } else {
        diasClass = 'text-success';
      }
      
      tr.innerHTML = `
        <td>${contrato.numero_contrato}</td>
        <td>${contrato.nombre_contratista}</td>
        <td>${contrato.objeto_contrato.substring(0, 50)}${contrato.objeto_contrato.length > 50 ? '...' : ''}</td>
        <td>${this.formatearFecha(contrato.fecha_final)}</td>
        <td class="${diasClass}">${diasRestantes} días</td>
        <td>
          <button class="btn btn-sm btn-outline" data-id="${contrato.id}" data-action="ver">
            <i class="fas fa-eye"></i>
          </button>
        </td>
      `;
      
      tbody.appendChild(tr);
      
      // Añadir evento al botón ver
      const btnVer = tr.querySelector('[data-action="ver"]');
      btnVer.addEventListener('click', () => {
        // Cambiar a la sección de contratos y mostrar el contrato
        document.querySelector('.sidebar-link[data-section="contratos"]').click();
        window.contratosManager.verContrato(contrato.id);
      });
    });
  }
  
  /**
   * Actualizar gráfico de distribución por estado
   */
  actualizarGraficoEstados() {
    if (!this.stats.porEstado) return;
    
    // Preparar datos para el gráfico
    const labels = [];
    const data = [];
    const backgroundColor = [];
    
    this.stats.porEstado.forEach(estado => {
      labels.push(this.capitalizarPrimeraLetra(estado.estado));
      data.push(estado.total);
      
      // Asignar color según estado
      switch (estado.estado) {
        case 'activo':
          backgroundColor.push('#2ecc71'); // Verde
          break;
        case 'revision':
          backgroundColor.push('#f39c12'); // Amarillo
          break;
        case 'expirado':
          backgroundColor.push('#e74c3c'); // Rojo
          break;
        default:
          backgroundColor.push('#3498db'); // Azul
      }
    });
    
    // Destruir gráfico existente si hay uno
    if (this.chartEstadosInstance) {
      this.chartEstadosInstance.destroy();
    }
    
    // Crear nuevo gráfico
    this.chartEstadosInstance = new Chart(this.chartEstados, {
      type: 'pie',
      data: {
        labels: labels,
        datasets: [{
          data: data,
          backgroundColor: backgroundColor,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
          },
          title: {
            display: true,
            text: 'Distribución de Contratos por Estado'
          }
        }
      }
    });
  }
  
  /**
   * Formatear fecha para mostrar en tabla
   * @param {string} fecha - Fecha en formato ISO
   * @returns {string} - Fecha formateada
   */
  formatearFecha(fecha) {
    if (!fecha) return '';
    
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(fecha).toLocaleDateString('es-ES', options);
  }
  
  /**
   * Capitalizar primera letra de un texto
   * @param {string} texto - Texto a capitalizar
   * @returns {string} - Texto con primera letra en mayúscula
   */
  capitalizarPrimeraLetra(texto) {
    if (!texto) return '';
    return texto.charAt(0).toUpperCase() + texto.slice(1);
  }
  
  /**
   * Inicializar el módulo
   */
  init() {
    // Cargar estadísticas al iniciar
    this.cargarEstadisticas();
    
    // Actualizar cada 5 minutos
    setInterval(() => this.cargarEstadisticas(), 5 * 60 * 1000);
  }
}

// Crear instancia y exportar
window.dashboardManager = new DashboardManager();
