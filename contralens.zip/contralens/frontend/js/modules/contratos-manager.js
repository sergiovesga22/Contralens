/**
 * contratos-manager.js
 * Módulo para gestionar la funcionalidad relacionada con contratos
 */

class ContratosManager {
  constructor() {
    // Referencias a elementos del DOM
    this.tablaContratos = document.getElementById('tabla-contratos');
    this.btnNuevoContrato = document.getElementById('btn-nuevo-contrato');
    this.modalContrato = document.getElementById('modal-contrato');
    this.formContrato = document.getElementById('form-contrato');
    this.btnCerrarModalContrato = document.getElementById('cerrar-modal-contrato');
    this.btnCancelarContrato = document.getElementById('cancelar-contrato');
    this.modalContratoTitulo = document.getElementById('modal-contrato-titulo');
    
    // Filtros
    this.filtroNumero = document.getElementById('filtro-numero');
    this.filtroContratista = document.getElementById('filtro-contratista');
    this.filtroEstado = document.getElementById('filtro-estado');
    this.btnAplicarFiltros = document.getElementById('btn-aplicar-filtros');
    this.btnLimpiarFiltros = document.getElementById('btn-limpiar-filtros');
    
    // Estado interno
    this.contratos = [];
    this.contratoActual = null;
    this.modoEdicion = false;
    
    // Inicializar eventos
    this.inicializarEventos();
  }
  
  /**
   * Inicializar eventos
   */
  inicializarEventos() {
    // Evento para abrir modal de nuevo contrato
    this.btnNuevoContrato.addEventListener('click', () => this.abrirModalNuevoContrato());
    
    // Evento para cerrar modal
    this.btnCerrarModalContrato.addEventListener('click', () => this.cerrarModalContrato());
    this.btnCancelarContrato.addEventListener('click', () => this.cerrarModalContrato());
    
    // Evento para enviar formulario
    this.formContrato.addEventListener('submit', (e) => this.guardarContrato(e));
    
    // Eventos para filtros
    this.btnAplicarFiltros.addEventListener('click', () => this.aplicarFiltros());
    this.btnLimpiarFiltros.addEventListener('click', () => this.limpiarFiltros());
  }
  
  /**
   * Cargar contratos desde la API
   * @param {object} filtros - Filtros para la búsqueda
   */
  async cargarContratos(filtros = {}) {
    try {
      const response = await ApiService.getContratos(filtros);
      
      if (response && response.success) {
        this.contratos = response.data;
        this.renderizarTablaContratos();
      }
    } catch (error) {
      console.error('Error al cargar contratos:', error);
    }
  }
  
  /**
   * Renderizar tabla de contratos
   */
  renderizarTablaContratos() {
    const tbody = this.tablaContratos.querySelector('tbody');
    tbody.innerHTML = '';
    
    if (this.contratos.length === 0) {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td colspan="8" class="text-center">No hay contratos disponibles</td>`;
      tbody.appendChild(tr);
      return;
    }
    
    this.contratos.forEach(contrato => {
      const tr = document.createElement('tr');
      
      // Formatear valores para mostrar
      const valorFinal = new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP' }).format(contrato.valor_final);
      
      // Determinar clase de estado
      let estadoClass = '';
      switch (contrato.estado) {
        case 'activo':
          estadoClass = 'text-success';
          break;
        case 'revision':
          estadoClass = 'text-warning';
          break;
        case 'expirado':
          estadoClass = 'text-danger';
          break;
      }
      
      tr.innerHTML = `
        <td>${contrato.numero_contrato}</td>
        <td>${contrato.nombre_contratista}</td>
        <td>${contrato.objeto_contrato.substring(0, 50)}${contrato.objeto_contrato.length > 50 ? '...' : ''}</td>
        <td>${valorFinal}</td>
        <td>${this.formatearFecha(contrato.fecha_inicio)}</td>
        <td>${this.formatearFecha(contrato.fecha_final)}</td>
        <td class="${estadoClass}">${this.capitalizarPrimeraLetra(contrato.estado)}</td>
        <td>
          <button class="btn btn-sm btn-outline" data-id="${contrato.id}" data-action="ver">
            <i class="fas fa-eye"></i>
          </button>
          <button class="btn btn-sm btn-outline" data-id="${contrato.id}" data-action="editar">
            <i class="fas fa-edit"></i>
          </button>
          <button class="btn btn-sm btn-danger" data-id="${contrato.id}" data-action="eliminar">
            <i class="fas fa-trash"></i>
          </button>
        </td>
      `;
      
      tbody.appendChild(tr);
      
      // Añadir eventos a los botones
      const btnVer = tr.querySelector('[data-action="ver"]');
      const btnEditar = tr.querySelector('[data-action="editar"]');
      const btnEliminar = tr.querySelector('[data-action="eliminar"]');
      
      btnVer.addEventListener('click', () => this.verContrato(contrato.id));
      btnEditar.addEventListener('click', () => this.editarContrato(contrato.id));
      btnEliminar.addEventListener('click', () => this.confirmarEliminarContrato(contrato.id));
    });
  }
  
  /**
   * Abrir modal para nuevo contrato
   */
  abrirModalNuevoContrato() {
    this.modoEdicion = false;
    this.contratoActual = null;
    this.modalContratoTitulo.textContent = 'Nuevo Contrato';
    this.formContrato.reset();
    this.modalContrato.style.display = 'block';
  }
  
  /**
   * Cerrar modal de contrato
   */
  cerrarModalContrato() {
    this.modalContrato.style.display = 'none';
    this.formContrato.reset();
  }
  
  /**
   * Ver detalles de un contrato
   * @param {number} id - ID del contrato
   */
  async verContrato(id) {
    try {
      const response = await ApiService.getContratoById(id);
      
      if (response && response.success) {
        const contrato = response.data;
        
        // Aquí se podría implementar una vista detallada del contrato
        // Por ahora, simplemente mostramos los datos en el modal en modo lectura
        this.contratoActual = contrato;
        this.modoEdicion = false;
        this.modalContratoTitulo.textContent = `Contrato: ${contrato.numero_contrato}`;
        
        // Llenar formulario con datos del contrato
        document.getElementById('contrato-convenio').value = contrato.convenio;
        document.getElementById('contrato-numero').value = contrato.numero_contrato;
        document.getElementById('contrato-contratista').value = contrato.nombre_contratista;
        document.getElementById('contrato-representante').value = contrato.representante_legal;
        document.getElementById('contrato-nit').value = contrato.nit_empresa;
        document.getElementById('contrato-objeto').value = contrato.objeto_contrato;
        document.getElementById('contrato-valor-inicial').value = contrato.valor_inicial;
        document.getElementById('contrato-valor-final').value = contrato.valor_final;
        document.getElementById('contrato-fecha-suscripcion').value = this.formatearFechaInput(contrato.fecha_suscripcion);
        document.getElementById('contrato-fecha-inicio').value = this.formatearFechaInput(contrato.fecha_inicio);
        document.getElementById('contrato-fecha-final').value = this.formatearFechaInput(contrato.fecha_final);
        document.getElementById('contrato-estado').value = contrato.estado;
        
        // Deshabilitar campos para modo lectura
        this.toggleCamposFormulario(false);
        
        this.modalContrato.style.display = 'block';
      }
    } catch (error) {
      console.error('Error al obtener contrato:', error);
    }
  }
  
  /**
   * Editar un contrato
   * @param {number} id - ID del contrato
   */
  async editarContrato(id) {
    try {
      const response = await ApiService.getContratoById(id);
      
      if (response && response.success) {
        const contrato = response.data;
        
        this.contratoActual = contrato;
        this.modoEdicion = true;
        this.modalContratoTitulo.textContent = `Editar Contrato: ${contrato.numero_contrato}`;
        
        // Llenar formulario con datos del contrato
        document.getElementById('contrato-convenio').value = contrato.convenio;
        document.getElementById('contrato-numero').value = contrato.numero_contrato;
        document.getElementById('contrato-contratista').value = contrato.nombre_contratista;
        document.getElementById('contrato-representante').value = contrato.representante_legal;
        document.getElementById('contrato-nit').value = contrato.nit_empresa;
        document.getElementById('contrato-objeto').value = contrato.objeto_contrato;
        document.getElementById('contrato-valor-inicial').value = contrato.valor_inicial;
        document.getElementById('contrato-valor-final').value = contrato.valor_final;
        document.getElementById('contrato-fecha-suscripcion').value = this.formatearFechaInput(contrato.fecha_suscripcion);
        document.getElementById('contrato-fecha-inicio').value = this.formatearFechaInput(contrato.fecha_inicio);
        document.getElementById('contrato-fecha-final').value = this.formatearFechaInput(contrato.fecha_final);
        document.getElementById('contrato-estado').value = contrato.estado;
        
        // Habilitar campos para edición
        this.toggleCamposFormulario(true);
        
        this.modalContrato.style.display = 'block';
      }
    } catch (error) {
      console.error('Error al obtener contrato para edición:', error);
    }
  }
  
  /**
   * Confirmar eliminación de un contrato
   * @param {number} id - ID del contrato
   */
  confirmarEliminarContrato(id) {
    if (confirm('¿Está seguro de eliminar este contrato? Esta acción no se puede deshacer.')) {
      this.eliminarContrato(id);
    }
  }
  
  /**
   * Eliminar un contrato
   * @param {number} id - ID del contrato
   */
  async eliminarContrato(id) {
    try {
      const response = await ApiService.deleteContrato(id);
      
      if (response && response.success) {
        ApiService.mostrarExito('Contrato eliminado exitosamente');
        this.cargarContratos(); // Recargar lista de contratos
      }
    } catch (error) {
      console.error('Error al eliminar contrato:', error);
    }
  }
  
  /**
   * Guardar un contrato (crear nuevo o actualizar existente)
   * @param {Event} e - Evento del formulario
   */
  async guardarContrato(e) {
    e.preventDefault();
    
    // Obtener datos del formulario
    const contratoData = {
      convenio: document.getElementById('contrato-convenio').value,
      numero_contrato: document.getElementById('contrato-numero').value,
      nombre_contratista: document.getElementById('contrato-contratista').value,
      representante_legal: document.getElementById('contrato-representante').value,
      nit_empresa: document.getElementById('contrato-nit').value,
      objeto_contrato: document.getElementById('contrato-objeto').value,
      valor_inicial: parseFloat(document.getElementById('contrato-valor-inicial').value),
      valor_final: parseFloat(document.getElementById('contrato-valor-final').value),
      fecha_suscripcion: document.getElementById('contrato-fecha-suscripcion').value,
      fecha_inicio: document.getElementById('contrato-fecha-inicio').value,
      fecha_final: document.getElementById('contrato-fecha-final').value,
      estado: document.getElementById('contrato-estado').value
    };
    
    try {
      let response;
      
      if (this.modoEdicion && this.contratoActual) {
        // Actualizar contrato existente
        response = await ApiService.updateContrato(this.contratoActual.id, contratoData);
        if (response && response.success) {
          ApiService.mostrarExito('Contrato actualizado exitosamente');
        }
      } else {
        // Crear nuevo contrato
        response = await ApiService.createContrato(contratoData);
        if (response && response.success) {
          ApiService.mostrarExito('Contrato creado exitosamente');
        }
      }
      
      // Cerrar modal y recargar lista
      this.cerrarModalContrato();
      this.cargarContratos();
      
    } catch (error) {
      console.error('Error al guardar contrato:', error);
    }
  }
  
  /**
   * Aplicar filtros de búsqueda
   */
  aplicarFiltros() {
    const filtros = {
      numero_contrato: this.filtroNumero.value,
      contratista: this.filtroContratista.value,
      estado: this.filtroEstado.value
    };
    
    this.cargarContratos(filtros);
  }
  
  /**
   * Limpiar filtros de búsqueda
   */
  limpiarFiltros() {
    this.filtroNumero.value = '';
    this.filtroContratista.value = '';
    this.filtroEstado.value = '';
    
    this.cargarContratos();
  }
  
  /**
   * Habilitar o deshabilitar campos del formulario
   * @param {boolean} enabled - True para habilitar, false para deshabilitar
   */
  toggleCamposFormulario(enabled) {
    const campos = this.formContrato.querySelectorAll('input, textarea, select');
    
    campos.forEach(campo => {
      campo.disabled = !enabled;
    });
    
    // Mostrar u ocultar botones según el modo
    const btnSubmit = this.formContrato.querySelector('button[type="submit"]');
    btnSubmit.style.display = enabled ? 'inline-block' : 'none';
  }
  
  /**
   * Formatear fecha para mostrar en tabla
   * @param {string} fecha - Fecha en formato ISO
   * @returns {string} - Fecha formateada
   */
  formatearFecha(fecha) {
    if (!fecha) return '';
    
    const options = { day: '2-digit', month: '2-digit', year: 'numeric' };
    return new Date(fecha).toLocaleDateString('es-ES', options);
  }
  
  /**
   * Formatear fecha para input type="date"
   * @param {string} fecha - Fecha en formato ISO
   * @returns {string} - Fecha formateada YYYY-MM-DD
   */
  formatearFechaInput(fecha) {
    if (!fecha) return '';
    
    const date = new Date(fecha);
    return date.toISOString().split('T')[0];
  }
  
  /**
   * Capitalizar primera letra de un texto
   * @param {string} texto - Texto a capitalizar
   * @returns {string} - Texto con primera letra en mayúscula
   */
  capitalizarPrimeraLetra(texto) {
    if (!texto) return '';
    return texto.charAt(0).toUpperCase() + texto.slice(1);
  }
  
  /**
   * Inicializar el módulo
   */
  init() {
    // Cargar contratos al iniciar
    this.cargarContratos();
  }
}

// Crear instancia y exportar
window.contratosManager = new ContratosManager();
