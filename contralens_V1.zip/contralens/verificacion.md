# Verificación de Funcionalidad - ContraLens

## Verificación del Backend

### 1. Verificación de la conexión a la base de datos
- **Objetivo**: Confirmar que el backend puede conectarse correctamente a la base de datos MySQL.
- **Procedimiento**:
  - Ejecutar el servidor backend con `node server.js`
  - Verificar en la consola el mensaje "Conexión a la base de datos establecida correctamente"
- **Resultado esperado**: Conexión exitosa sin errores.

### 2. Verificación de rutas de autenticación
- **Objetivo**: Confirmar que las rutas de autenticación funcionan correctamente.
- **Procedimiento**:
  - Probar la ruta POST `/api/auth/login` con credenciales válidas
  - Probar la ruta POST `/api/auth/register` para crear un nuevo usuario
  - Probar la ruta GET `/api/auth/profile` con un token válido
- **Resultado esperado**: Respuestas JSON correctas para cada operación.

### 3. Verificación de rutas de contratos
- **Objetivo**: Confirmar que las operaciones CRUD de contratos funcionan correctamente.
- **Procedimiento**:
  - Probar la ruta GET `/api/contratos` para listar contratos
  - Probar la ruta POST `/api/contratos` para crear un nuevo contrato
  - Probar la ruta GET `/api/contratos/:id` para obtener un contrato específico
  - Probar la ruta PUT `/api/contratos/:id` para actualizar un contrato
  - Probar la ruta DELETE `/api/contratos/:id` para eliminar un contrato
- **Resultado esperado**: Operaciones CRUD exitosas con respuestas JSON correctas.

### 4. Verificación de rutas de supervisión
- **Objetivo**: Confirmar que las operaciones de supervisión funcionan correctamente.
- **Procedimiento**:
  - Probar la ruta GET `/api/supervision/contrato/:contratoId` para listar registros de supervisión
  - Probar la ruta POST `/api/supervision` para crear un nuevo registro
  - Probar la ruta GET `/api/supervision/alerts` para obtener alertas de prioridad alta
- **Resultado esperado**: Operaciones exitosas con respuestas JSON correctas.

### 5. Verificación de rutas de documentos
- **Objetivo**: Confirmar que las operaciones de documentos funcionan correctamente.
- **Procedimiento**:
  - Probar la ruta GET `/api/documentos/contrato/:contratoId` para listar documentos
  - Probar la ruta POST `/api/documentos` para crear un nuevo documento
  - Probar la ruta GET `/api/documentos/search` para buscar documentos
- **Resultado esperado**: Operaciones exitosas con respuestas JSON correctas.

## Verificación del Frontend

### 1. Verificación de la página de login
- **Objetivo**: Confirmar que la página de login funciona correctamente.
- **Procedimiento**:
  - Abrir `login.html` en el navegador
  - Intentar iniciar sesión con credenciales válidas
  - Intentar iniciar sesión con credenciales inválidas
  - Probar la funcionalidad de registro
- **Resultado esperado**: Inicio de sesión exitoso con redirección al dashboard, mensajes de error apropiados para credenciales inválidas.

### 2. Verificación del dashboard
- **Objetivo**: Confirmar que el dashboard muestra correctamente las estadísticas y datos.
- **Procedimiento**:
  - Iniciar sesión y verificar que el dashboard se carga
  - Verificar que se muestran las estadísticas (contratos totales, activos, etc.)
  - Verificar que se muestra la tabla de contratos próximos a vencer
  - Verificar que el gráfico de distribución por estado se renderiza correctamente
- **Resultado esperado**: Dashboard con datos correctos y visualizaciones funcionales.

### 3. Verificación de gestión de contratos
- **Objetivo**: Confirmar que la gestión de contratos funciona correctamente.
- **Procedimiento**:
  - Navegar a la sección de contratos
  - Crear un nuevo contrato
  - Editar un contrato existente
  - Eliminar un contrato
  - Aplicar filtros de búsqueda
- **Resultado esperado**: Operaciones CRUD exitosas con actualización de la interfaz.

### 4. Verificación del módulo de supervisión
- **Objetivo**: Confirmar que el módulo de supervisión funciona correctamente.
- **Procedimiento**:
  - Navegar a la sección de supervisión
  - Verificar que se muestran las alertas de supervisión
  - Crear un nuevo registro de supervisión
  - Filtrar registros de supervisión
- **Resultado esperado**: Operaciones exitosas con actualización de la interfaz.

### 5. Verificación del módulo de reportes
- **Objetivo**: Confirmar que el módulo de reportes funciona correctamente.
- **Procedimiento**:
  - Navegar a la sección de reportes
  - Generar un reporte con diferentes filtros
  - Verificar que se muestra el resumen del reporte
  - Verificar que se genera el gráfico del reporte
  - Guardar un reporte y cargarlo posteriormente
- **Resultado esperado**: Generación y visualización correcta de reportes.

## Verificación de Integración

### 1. Verificación de comunicación entre frontend y backend
- **Objetivo**: Confirmar que el frontend se comunica correctamente con el backend.
- **Procedimiento**:
  - Verificar en las herramientas de desarrollo del navegador (pestaña Network) que las peticiones al backend se realizan correctamente
  - Verificar que las respuestas del backend son procesadas correctamente por el frontend
- **Resultado esperado**: Comunicación fluida sin errores de CORS o conexión.

### 2. Verificación de scripts de inicio
- **Objetivo**: Confirmar que los scripts de inicio funcionan correctamente.
- **Procedimiento**:
  - Ejecutar `start.sh` en Linux/macOS o `start.bat` en Windows
  - Verificar que el backend se inicia correctamente
  - Verificar que el frontend se abre en el navegador
- **Resultado esperado**: Inicio completo de la aplicación sin errores.

### 3. Verificación del flujo completo de la aplicación
- **Objetivo**: Confirmar que el flujo completo de la aplicación funciona correctamente.
- **Procedimiento**:
  - Iniciar sesión
  - Crear un nuevo contrato
  - Añadir un registro de supervisión para ese contrato
  - Generar un reporte que incluya ese contrato
  - Cerrar sesión y volver a iniciar sesión
- **Resultado esperado**: Flujo completo sin errores, con persistencia de datos entre sesiones.

## Registro de Pruebas

| Prueba | Fecha | Resultado | Observaciones |
|--------|-------|-----------|---------------|
|        |       |           |               |
|        |       |           |               |
|        |       |           |               |

## Problemas Conocidos

- Problema 1: [Descripción]
  - Solución temporal: [Descripción]
  
- Problema 2: [Descripción]
  - Solución temporal: [Descripción]
