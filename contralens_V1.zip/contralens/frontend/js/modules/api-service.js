/**
 * api-service.js
 * Módulo para gestionar las comunicaciones con la API del backend
 */

// Configuración de la API
const API_URL = 'http://localhost:3000/api';
let authToken = localStorage.getItem('authToken');

// Clase principal para gestionar las peticiones a la API
class ApiService {
  /**
   * Realiza una petición a la API
   * @param {string} endpoint - Endpoint de la API
   * @param {string} method - Método HTTP (GET, POST, PUT, DELETE)
   * @param {object} data - Datos a enviar (opcional)
   * @returns {Promise} - Promesa con la respuesta
   */
  static async fetchAPI(endpoint, method = 'GET', data = null) {
    const url = `${API_URL}${endpoint}`;
    
    const headers = {
      'Content-Type': 'application/json'
    };
    
    // Añadir token de autenticación si existe
    if (authToken) {
      headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    const options = {
      method,
      headers,
      credentials: 'include'
    };
    
    // Añadir cuerpo de la petición si hay datos
    if (data && (method === 'POST' || method === 'PUT')) {
      options.body = JSON.stringify(data);
    }
    
    try {
      const response = await fetch(url, options);
      
      // Si la respuesta es 401 (No autorizado), redirigir al login
      if (response.status === 401) {
        this.logout();
        window.location.href = 'login.html';
        return null;
      }
      
      const responseData = await response.json();
      
      if (!response.ok) {
        throw new Error(responseData.message || 'Error en la petición');
      }
      
      return responseData;
    } catch (error) {
      console.error('Error en la petición a la API:', error);
      this.mostrarError(error.message);
      throw error;
    }
  }
  
  /**
   * Iniciar sesión
   * @param {string} email - Email del usuario
   * @param {string} password - Contraseña del usuario
   * @returns {Promise} - Promesa con los datos del usuario
   */
  static async login(email, password) {
    try {
      const response = await this.fetchAPI('/auth/login', 'POST', { email, password });
      
      if (response && response.success) {
        // Guardar token en localStorage
        localStorage.setItem('authToken', response.data.token);
        localStorage.setItem('userData', JSON.stringify(response.data.user));
        authToken = response.data.token;
        
        return response.data.user;
      }
      
      return null;
    } catch (error) {
      console.error('Error en login:', error);
      throw error;
    }
  }
  
  /**
   * Cerrar sesión
   */
  static logout() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('userData');
    authToken = null;
    window.location.href = 'login.html';
  }
  
  /**
   * Registrar nuevo usuario
   * @param {object} userData - Datos del usuario
   * @returns {Promise} - Promesa con la respuesta
   */
  static async register(userData) {
    return await this.fetchAPI('/auth/register', 'POST', userData);
  }
  
  /**
   * Obtener perfil del usuario actual
   * @returns {Promise} - Promesa con los datos del usuario
   */
  static async getProfile() {
    return await this.fetchAPI('/auth/profile');
  }
  
  /**
   * Actualizar perfil del usuario
   * @param {object} userData - Datos del usuario a actualizar
   * @returns {Promise} - Promesa con la respuesta
   */
  static async updateProfile(userData) {
    return await this.fetchAPI('/auth/profile', 'PUT', userData);
  }
  
  /**
   * Obtener todos los contratos
   * @param {object} filters - Filtros para la búsqueda (opcional)
   * @returns {Promise} - Promesa con los contratos
   */
  static async getContratos(filters = {}) {
    // Construir query string para los filtros
    const queryParams = new URLSearchParams();
    
    Object.keys(filters).forEach(key => {
      if (filters[key]) {
        queryParams.append(key, filters[key]);
      }
    });
    
    const queryString = queryParams.toString() ? `?${queryParams.toString()}` : '';
    
    return await this.fetchAPI(`/contratos${queryString}`);
  }
  
  /**
   * Obtener un contrato por ID
   * @param {number} id - ID del contrato
   * @returns {Promise} - Promesa con el contrato
   */
  static async getContratoById(id) {
    return await this.fetchAPI(`/contratos/${id}`);
  }
  
  /**
   * Crear un nuevo contrato
   * @param {object} contratoData - Datos del contrato
   * @returns {Promise} - Promesa con la respuesta
   */
  static async createContrato(contratoData) {
    return await this.fetchAPI('/contratos', 'POST', contratoData);
  }
  
  /**
   * Actualizar un contrato
   * @param {number} id - ID del contrato
   * @param {object} contratoData - Datos del contrato a actualizar
   * @returns {Promise} - Promesa con la respuesta
   */
  static async updateContrato(id, contratoData) {
    return await this.fetchAPI(`/contratos/${id}`, 'PUT', contratoData);
  }
  
  /**
   * Eliminar un contrato
   * @param {number} id - ID del contrato
   * @returns {Promise} - Promesa con la respuesta
   */
  static async deleteContrato(id) {
    return await this.fetchAPI(`/contratos/${id}`, 'DELETE');
  }
  
  /**
   * Obtener estadísticas para el dashboard
   * @returns {Promise} - Promesa con las estadísticas
   */
  static async getStats() {
    return await this.fetchAPI('/contratos/stats');
  }
  
  /**
   * Obtener registros de supervisión de un contrato
   * @param {number} contratoId - ID del contrato
   * @returns {Promise} - Promesa con los registros de supervisión
   */
  static async getSupervisionByContrato(contratoId) {
    return await this.fetchAPI(`/supervision/contrato/${contratoId}`);
  }
  
  /**
   * Crear un nuevo registro de supervisión
   * @param {object} supervisionData - Datos de la supervisión
   * @returns {Promise} - Promesa con la respuesta
   */
  static async createSupervision(supervisionData) {
    return await this.fetchAPI('/supervision', 'POST', supervisionData);
  }
  
  /**
   * Actualizar un registro de supervisión
   * @param {number} id - ID del registro de supervisión
   * @param {object} supervisionData - Datos de la supervisión a actualizar
   * @returns {Promise} - Promesa con la respuesta
   */
  static async updateSupervision(id, supervisionData) {
    return await this.fetchAPI(`/supervision/${id}`, 'PUT', supervisionData);
  }
  
  /**
   * Eliminar un registro de supervisión
   * @param {number} id - ID del registro de supervisión
   * @returns {Promise} - Promesa con la respuesta
   */
  static async deleteSupervision(id) {
    return await this.fetchAPI(`/supervision/${id}`, 'DELETE');
  }
  
  /**
   * Obtener alertas de supervisión con prioridad alta
   * @returns {Promise} - Promesa con las alertas
   */
  static async getPriorityAlerts() {
    return await this.fetchAPI('/supervision/alerts');
  }
  
  /**
   * Obtener documentos de un contrato
   * @param {number} contratoId - ID del contrato
   * @returns {Promise} - Promesa con los documentos
   */
  static async getDocumentosByContrato(contratoId) {
    return await this.fetchAPI(`/documentos/contrato/${contratoId}`);
  }
  
  /**
   * Crear un nuevo documento
   * @param {object} documentoData - Datos del documento
   * @returns {Promise} - Promesa con la respuesta
   */
  static async createDocumento(documentoData) {
    return await this.fetchAPI('/documentos', 'POST', documentoData);
  }
  
  /**
   * Eliminar un documento
   * @param {number} id - ID del documento
   * @returns {Promise} - Promesa con la respuesta
   */
  static async deleteDocumento(id) {
    return await this.fetchAPI(`/documentos/${id}`, 'DELETE');
  }
  
  /**
   * Buscar documentos
   * @param {string} term - Término de búsqueda
   * @returns {Promise} - Promesa con los documentos
   */
  static async searchDocumentos(term) {
    return await this.fetchAPI(`/documentos/search?term=${term}`);
  }
  
  /**
   * Mostrar mensaje de error
   * @param {string} message - Mensaje de error
   */
  static mostrarError(message) {
    // Implementar según la UI (puede ser un toast, alert, etc.)
    console.error(message);
    
    // Ejemplo con alert (en producción usar un componente de UI)
    alert(`Error: ${message}`);
  }
  
  /**
   * Mostrar mensaje de éxito
   * @param {string} message - Mensaje de éxito
   */
  static mostrarExito(message) {
    // Implementar según la UI (puede ser un toast, alert, etc.)
    console.log(message);
    
    // Ejemplo con alert (en producción usar un componente de UI)
    alert(`Éxito: ${message}`);
  }
  
  /**
   * Verificar si el usuario está autenticado
   * @returns {boolean} - True si está autenticado, false en caso contrario
   */
  static isAuthenticated() {
    return !!authToken;
  }
  
  /**
   * Obtener datos del usuario actual
   * @returns {object|null} - Datos del usuario o null si no está autenticado
   */
  static getCurrentUser() {
    const userData = localStorage.getItem('userData');
    return userData ? JSON.parse(userData) : null;
  }
}

// Exportar la clase
window.ApiService = ApiService;
