/**
 * security-module.js
 * Módulo para gestionar la seguridad y autenticación de la aplicación
 */

class SecurityModule {
  constructor() {
    // Referencias a elementos del DOM
    this.navLogout = document.getElementById('nav-logout');
    this.navPerfil = document.getElementById('nav-perfil');
    
    // Estado interno
    this.currentUser = null;
    
    // Inicializar eventos
    this.inicializarEventos();
  }
  
  /**
   * Inicializar eventos
   */
  inicializarEventos() {
    // Evento para cerrar sesión
    this.navLogout.addEventListener('click', (e) => {
      e.preventDefault();
      this.logout();
    });
    
    // Evento para ver perfil (se implementaría en una versión más completa)
    this.navPerfil.addEventListener('click', (e) => {
      e.preventDefault();
      this.mostrarPerfil();
    });
  }
  
  /**
   * Verificar si el usuario está autenticado
   * @returns {boolean} - True si está autenticado, false en caso contrario
   */
  verificarAutenticacion() {
    const isAuthenticated = ApiService.isAuthenticated();
    
    if (!isAuthenticated) {
      // Redirigir a la página de login si no está en ella
      if (!window.location.pathname.includes('login.html')) {
        window.location.href = 'login.html';
      }
      return false;
    }
    
    // Obtener datos del usuario actual
    this.currentUser = ApiService.getCurrentUser();
    return true;
  }
  
  /**
   * Iniciar sesión
   * @param {string} email - Email del usuario
   * @param {string} password - Contraseña del usuario
   * @returns {Promise<boolean>} - True si el login fue exitoso, false en caso contrario
   */
  async login(email, password) {
    try {
      const user = await ApiService.login(email, password);
      
      if (user) {
        // Redirigir al dashboard
        window.location.href = 'index.html';
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('Error en login:', error);
      return false;
    }
  }
  
  /**
   * Cerrar sesión
   */
  logout() {
    if (confirm('¿Está seguro que desea cerrar sesión?')) {
      ApiService.logout();
    }
  }
  
  /**
   * Mostrar perfil del usuario
   */
  async mostrarPerfil() {
    try {
      const response = await ApiService.getProfile();
      
      if (response && response.success) {
        const user = response.data;
        
        // Aquí se implementaría la lógica para mostrar el perfil
        // Por ahora, solo mostramos un alert con la información
        alert(`
          Perfil de Usuario:
          Nombre: ${user.nombre}
          Email: ${user.email}
          Rol: ${this.capitalizarPrimeraLetra(user.rol)}
        `);
      }
    } catch (error) {
      console.error('Error al obtener perfil:', error);
    }
  }
  
  /**
   * Verificar permisos según rol
   * @param {string} requiredRole - Rol requerido ('admin', 'editor')
   * @returns {boolean} - True si tiene permisos, false en caso contrario
   */
  verificarPermisos(requiredRole) {
    if (!this.currentUser) {
      return false;
    }
    
    // Si se requiere rol de admin
    if (requiredRole === 'admin') {
      return this.currentUser.rol === 'admin';
    }
    
    // Si se requiere rol de editor o admin
    if (requiredRole === 'editor') {
      return this.currentUser.rol === 'admin' || this.currentUser.rol === 'editor';
    }
    
    // Cualquier usuario autenticado
    return true;
  }
  
  /**
   * Mostrar u ocultar elementos según permisos
   */
  aplicarPermisosUI() {
    // Elementos que requieren permisos de editor o admin
    const elementosEditor = document.querySelectorAll('.requiere-editor');
    
    // Elementos que requieren permisos de admin
    const elementosAdmin = document.querySelectorAll('.requiere-admin');
    
    // Aplicar visibilidad según permisos
    elementosEditor.forEach(elemento => {
      elemento.style.display = this.verificarPermisos('editor') ? '' : 'none';
    });
    
    elementosAdmin.forEach(elemento => {
      elemento.style.display = this.verificarPermisos('admin') ? '' : 'none';
    });
  }
  
  /**
   * Validar contraseña segura
   * @param {string} password - Contraseña a validar
   * @returns {object} - Objeto con resultado y mensaje
   */
  validarPassword(password) {
    // Debe tener al menos 8 caracteres
    if (password.length < 8) {
      return {
        valido: false,
        mensaje: 'La contraseña debe tener al menos 8 caracteres'
      };
    }
    
    // Debe tener al menos una letra mayúscula
    if (!/[A-Z]/.test(password)) {
      return {
        valido: false,
        mensaje: 'La contraseña debe tener al menos una letra mayúscula'
      };
    }
    
    // Debe tener al menos una letra minúscula
    if (!/[a-z]/.test(password)) {
      return {
        valido: false,
        mensaje: 'La contraseña debe tener al menos una letra minúscula'
      };
    }
    
    // Debe tener al menos un número
    if (!/\d/.test(password)) {
      return {
        valido: false,
        mensaje: 'La contraseña debe tener al menos un número'
      };
    }
    
    return {
      valido: true,
      mensaje: 'Contraseña válida'
    };
  }
  
  /**
   * Validar formato de email
   * @param {string} email - Email a validar
   * @returns {boolean} - True si es válido, false en caso contrario
   */
  validarEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  }
  
  /**
   * Capitalizar primera letra de un texto
   * @param {string} texto - Texto a capitalizar
   * @returns {string} - Texto con primera letra en mayúscula
   */
  capitalizarPrimeraLetra(texto) {
    if (!texto) return '';
    return texto.charAt(0).toUpperCase() + texto.slice(1);
  }
  
  /**
   * Inicializar el módulo
   */
  init() {
    // Verificar autenticación
    const isAuthenticated = this.verificarAutenticacion();
    
    if (isAuthenticated) {
      // Aplicar permisos a la UI
      this.aplicarPermisosUI();
    }
  }
}

// Crear instancia y exportar
window.securityModule = new SecurityModule();
