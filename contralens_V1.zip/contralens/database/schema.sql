-- database/schema.sql

-- Tabla de usuarios
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol ENUM('admin', 'editor', 'usuario') DEFAULT 'usuario',
  fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabla de contratos
CREATE TABLE contratos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  convenio VARCHAR(100) NOT NULL,
  numero_contrato VARCHAR(50) NOT NULL UNIQUE,
  nombre_contratista VARCHAR(200) NOT NULL,
  representante_legal VARCHAR(200) NOT NULL,
  nit_empresa VARCHAR(20) NOT NULL,
  objeto_contrato TEXT NOT NULL,
  valor_inicial DECIMAL(15, 2) NOT NULL,
  valor_final DECIMAL(15, 2) NOT NULL,
  fecha_suscripcion DATE NOT NULL,
  fecha_inicio DATE NOT NULL,
  fecha_final DATE NOT NULL,
  estado ENUM('activo', 'revision', 'expirado') DEFAULT 'activo',
  usuario_id INT NOT NULL,
  fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  fecha_actualizacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabla de adiciones
CREATE TABLE adiciones (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contrato_id INT NOT NULL,
  valor DECIMAL(15, 2) NOT NULL,
  fecha DATE NOT NULL,
  FOREIGN KEY (contrato_id) REFERENCES contratos(id) ON DELETE CASCADE
);

-- Tabla de prórrogas
CREATE TABLE prorrogas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contrato_id INT NOT NULL,
  descripcion TEXT NOT NULL,
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NOT NULL,
  FOREIGN KEY (contrato_id) REFERENCES contratos(id) ON DELETE CASCADE
);

-- Tabla de pólizas
CREATE TABLE polizas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contrato_id INT NOT NULL,
  numero VARCHAR(50) NOT NULL,
  descripcion TEXT,
  fecha_expedicion DATE NOT NULL,
  fecha_vencimiento DATE NOT NULL,
  FOREIGN KEY (contrato_id) REFERENCES contratos(id) ON DELETE CASCADE
);

-- Tabla de supervisión
CREATE TABLE supervision (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contrato_id INT NOT NULL,
  usuario_id INT NOT NULL,
  observaciones TEXT NOT NULL,
  prioridad ENUM('alta', 'normal', 'baja') DEFAULT 'normal',
  fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (contrato_id) REFERENCES contratos(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabla de documentos
CREATE TABLE documentos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  contrato_id INT NOT NULL,
  usuario_id INT NOT NULL,
  nombre VARCHAR(255) NOT NULL,
  descripcion TEXT,
  url VARCHAR(500) NOT NULL,
  tipo VARCHAR(50),
  fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (contrato_id) REFERENCES contratos(id) ON DELETE CASCADE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Crear usuario administrador inicial (contraseña: Admin123)
INSERT INTO usuarios (nombre, email, password, rol) 
VALUES ('Administrador', 'admin@contralens.com', '$2b$10$iq7WzCVnXlMIe1c8Vr4rueT0BK5hUaWf0oBMGRK3JZI.ZGeKqWVN2', 'admin');
