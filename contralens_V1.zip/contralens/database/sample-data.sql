-- database/sample-data.sql

-- Insertar datos de ejemplo en la tabla usuarios
INSERT INTO usuarios (nombre, email, password, rol) 
VALUES 
('Juan Pérez', 'juan@contralens.com', '$2b$10$iq7WzCVnXlMIe1c8Vr4rueT0BK5hUaWf0oBMGRK3JZI.ZGeKqWVN2', 'editor'),
('María López', 'maria@contralens.com', '$2b$10$iq7WzCVnXlMIe1c8Vr4rueT0BK5hUaWf0oBMGRK3JZI.ZGeKqWVN2', 'usuario');

-- Insertar datos de ejemplo en la tabla contratos
INSERT INTO contratos (convenio, numero_contrato, nombre_contratista, representante_legal, nit_empresa, objeto_contrato, valor_inicial, valor_final, fecha_suscripcion, fecha_inicio, fecha_final, estado, usuario_id) 
VALUES 
('Convenio A', 'CT-2025-001', 'Constructora XYZ', 'Carlos Rodríguez', '900123456-7', 'Construcción de puente peatonal', 250000000.00, 275000000.00, '2025-01-15', '2025-02-01', '2025-08-01', 'activo', 1),
('Convenio B', 'CT-2025-002', 'Servicios Tecnológicos ABC', 'Ana Martínez', '901234567-8', 'Implementación de sistema de monitoreo', 120000000.00, 120000000.00, '2025-02-10', '2025-02-20', '2025-05-20', 'activo', 1),
('Convenio A', 'CT-2025-003', 'Consultores Asociados', 'Pedro Gómez', '902345678-9', 'Estudio de factibilidad ambiental', 85000000.00, 95000000.00, '2025-01-20', '2025-02-01', '2025-04-30', 'revision', 2);

-- Insertar datos de ejemplo en la tabla adiciones
INSERT INTO adiciones (contrato_id, valor, fecha) 
VALUES 
(1, 25000000.00, '2025-04-15'),
(3, 10000000.00, '2025-03-10');

-- Insertar datos de ejemplo en la tabla prórrogas
INSERT INTO prorrogas (contrato_id, descripcion, fecha_inicio, fecha_fin) 
VALUES 
(1, 'Prórroga por condiciones climáticas', '2025-08-02', '2025-09-15'),
(2, 'Ampliación para pruebas adicionales', '2025-05-21', '2025-06-20');

-- Insertar datos de ejemplo en la tabla pólizas
INSERT INTO polizas (contrato_id, numero, descripcion, fecha_expedicion, fecha_vencimiento) 
VALUES 
(1, 'POL-2025-001', 'Póliza de cumplimiento', '2025-01-20', '2025-10-01'),
(1, 'POL-2025-002', 'Póliza de responsabilidad civil', '2025-01-20', '2025-10-01'),
(2, 'POL-2025-003', 'Póliza de cumplimiento', '2025-02-15', '2025-07-20');

-- Insertar datos de ejemplo en la tabla supervisión
INSERT INTO supervision (contrato_id, usuario_id, observaciones, prioridad) 
VALUES 
(1, 1, 'Avance del 30% en la construcción de cimientos', 'normal'),
(1, 1, 'Retraso por lluvias, se requiere ajuste en cronograma', 'alta'),
(2, 2, 'Instalación de equipos completada al 50%', 'normal'),
(3, 2, 'Pendiente entrega de informe preliminar', 'baja');

-- Insertar datos de ejemplo en la tabla documentos
INSERT INTO documentos (contrato_id, usuario_id, nombre, descripcion, url, tipo) 
VALUES 
(1, 1, 'Planos_Puente.pdf', 'Planos técnicos del puente', '/documentos/contratos/CT-2025-001/planos.pdf', 'pdf'),
(1, 1, 'Cronograma_Actualizado.xlsx', 'Cronograma con ajustes por clima', '/documentos/contratos/CT-2025-001/cronograma_v2.xlsx', 'excel'),
(2, 1, 'Especificaciones_Tecnicas.pdf', 'Detalles técnicos de equipos', '/documentos/contratos/CT-2025-002/especificaciones.pdf', 'pdf'),
(3, 2, 'Informe_Preliminar.docx', 'Borrador de informe de factibilidad', '/documentos/contratos/CT-2025-003/informe_preliminar.docx', 'word');
