#!/bin/bash

# Script de inicio para ContraLens
# Este script inicia el backend y abre el frontend en el navegador

# Colores para mensajes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}Iniciando ContraLens...${NC}"

# Verificar si Node.js está instalado
if ! command -v node &> /dev/null; then
    echo -e "${RED}Error: Node.js no está instalado.${NC}"
    echo "Por favor, instale Node.js desde https://nodejs.org/"
    exit 1
fi

# Directorio base del proyecto
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$BASE_DIR/backend"
FRONTEND_DIR="$BASE_DIR/frontend"

# Verificar si el directorio backend existe
if [ ! -d "$BACKEND_DIR" ]; then
    echo -e "${RED}Error: No se encontró el directorio backend.${NC}"
    exit 1
fi

# Verificar si el directorio frontend existe
if [ ! -d "$FRONTEND_DIR" ]; then
    echo -e "${RED}Error: No se encontró el directorio frontend.${NC}"
    exit 1
fi

# Instalar dependencias del backend si no están instaladas
if [ ! -d "$BACKEND_DIR/node_modules" ]; then
    echo -e "${YELLOW}Instalando dependencias del backend...${NC}"
    cd "$BACKEND_DIR" && npm install
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error: No se pudieron instalar las dependencias del backend.${NC}"
        exit 1
    fi
fi

# Iniciar el servidor backend
echo -e "${YELLOW}Iniciando servidor backend...${NC}"
cd "$BACKEND_DIR" && node server.js &
BACKEND_PID=$!

# Esperar a que el servidor esté listo
echo -e "${YELLOW}Esperando a que el servidor esté listo...${NC}"
sleep 5

# Verificar si el servidor está en ejecución
if ! ps -p $BACKEND_PID > /dev/null; then
    echo -e "${RED}Error: El servidor backend no pudo iniciarse.${NC}"
    exit 1
fi

# Abrir el frontend en el navegador predeterminado
echo -e "${YELLOW}Abriendo frontend en el navegador...${NC}"
if command -v xdg-open &> /dev/null; then
    # Linux
    xdg-open "$FRONTEND_DIR/login.html"
elif command -v open &> /dev/null; then
    # macOS
    open "$FRONTEND_DIR/login.html"
elif command -v start &> /dev/null; then
    # Windows
    start "$FRONTEND_DIR/login.html"
else
    echo -e "${YELLOW}No se pudo abrir automáticamente el navegador.${NC}"
    echo -e "Por favor, abra manualmente: ${GREEN}$FRONTEND_DIR/login.html${NC}"
fi

echo -e "${GREEN}ContraLens se ha iniciado correctamente.${NC}"
echo -e "Servidor backend ejecutándose en: ${GREEN}http://localhost:3000${NC}"
echo -e "Para detener el servidor, presione Ctrl+C"

# Mantener el script en ejecución
wait $BACKEND_PID
