// Controlador de autenticación
const Usuario = require('../models/usuario');
const jwt = require('jsonwebtoken');
require('dotenv').config();

// Iniciar sesión
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Validar datos de entrada
    if (!email || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'Email y contraseña son requeridos' 
      });
    }
    
    // Verificar credenciales
    const user = await Usuario.verifyCredentials(email, password);
    
    if (!user) {
      return res.status(401).json({ 
        success: false, 
        message: 'Credenciales inválidas' 
      });
    }
    
    // Generar token JWT
    const token = jwt.sign(
      { id: user.id, email: user.email, rol: user.rol },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRATION }
    );
    
    res.json({
      success: true,
      message: 'Inicio de sesión exitoso',
      data: {
        token,
        user: {
          id: user.id,
          nombre: user.nombre,
          email: user.email,
          rol: user.rol
        }
      }
    });
  } catch (error) {
    console.error('Error en login:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Registrar nuevo usuario
exports.register = async (req, res) => {
  try {
    const { nombre, email, password, rol } = req.body;
    
    // Validar datos de entrada
    if (!nombre || !email || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'Nombre, email y contraseña son requeridos' 
      });
    }
    
    // Verificar si el email ya existe
    const existingUser = await Usuario.getByEmail(email);
    
    if (existingUser) {
      return res.status(400).json({ 
        success: false, 
        message: 'El email ya está registrado' 
      });
    }
    
    // Crear nuevo usuario
    const newUser = await Usuario.create({
      nombre,
      email,
      password,
      rol: rol || 'usuario'
    });
    
    res.status(201).json({
      success: true,
      message: 'Usuario registrado exitosamente',
      data: {
        id: newUser.id,
        nombre: newUser.nombre,
        email: newUser.email,
        rol: newUser.rol
      }
    });
  } catch (error) {
    console.error('Error en registro:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Obtener perfil del usuario actual
exports.getProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    
    const user = await Usuario.getById(userId);
    
    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: 'Usuario no encontrado' 
      });
    }
    
    res.json({
      success: true,
      data: user
    });
  } catch (error) {
    console.error('Error al obtener perfil:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Actualizar perfil del usuario
exports.updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const { nombre, email, password } = req.body;
    
    // Verificar si el usuario existe
    const user = await Usuario.getById(userId);
    
    if (!user) {
      return res.status(404).json({ 
        success: false, 
        message: 'Usuario no encontrado' 
      });
    }
    
    // Actualizar usuario
    const updated = await Usuario.update(userId, {
      nombre,
      email,
      password
    });
    
    if (!updated) {
      return res.status(400).json({ 
        success: false, 
        message: 'No se pudo actualizar el perfil' 
      });
    }
    
    res.json({
      success: true,
      message: 'Perfil actualizado exitosamente'
    });
  } catch (error) {
    console.error('Error al actualizar perfil:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};
