// Controlador de documentos
const Documento = require('../models/documento');

// Obtener todos los documentos de un contrato
exports.getAllByContrato = async (req, res) => {
  try {
    const contratoId = req.params.contratoId;
    
    const documentos = await Documento.getAllByContrato(contratoId);
    
    res.json({
      success: true,
      data: documentos
    });
  } catch (error) {
    console.error('Error al obtener documentos:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Obtener documento por ID
exports.getById = async (req, res) => {
  try {
    const documentoId = req.params.id;
    
    const documento = await Documento.getById(documentoId);
    
    if (!documento) {
      return res.status(404).json({ 
        success: false, 
        message: 'Documento no encontrado' 
      });
    }
    
    res.json({
      success: true,
      data: documento
    });
  } catch (error) {
    console.error('Error al obtener documento:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Crear nuevo documento
exports.create = async (req, res) => {
  try {
    const documentoData = {
      ...req.body,
      usuario_id: req.user.id // Obtener el ID del usuario autenticado
    };
    
    // Validar datos de entrada
    if (!documentoData.contrato_id || !documentoData.nombre || !documentoData.url) {
      return res.status(400).json({ 
        success: false, 
        message: 'Contrato ID, nombre y URL son requeridos' 
      });
    }
    
    // Crear nuevo documento
    const newDocumento = await Documento.create(documentoData);
    
    res.status(201).json({
      success: true,
      message: 'Documento creado exitosamente',
      data: newDocumento
    });
  } catch (error) {
    console.error('Error al crear documento:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Actualizar documento
exports.update = async (req, res) => {
  try {
    const documentoId = req.params.id;
    const documentoData = req.body;
    
    // Verificar si el documento existe
    const documento = await Documento.getById(documentoId);
    
    if (!documento) {
      return res.status(404).json({ 
        success: false, 
        message: 'Documento no encontrado' 
      });
    }
    
    // Actualizar documento
    const updated = await Documento.update(documentoId, documentoData);
    
    if (!updated) {
      return res.status(400).json({ 
        success: false, 
        message: 'No se pudo actualizar el documento' 
      });
    }
    
    res.json({
      success: true,
      message: 'Documento actualizado exitosamente'
    });
  } catch (error) {
    console.error('Error al actualizar documento:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Eliminar documento
exports.delete = async (req, res) => {
  try {
    const documentoId = req.params.id;
    
    // Verificar si el documento existe
    const documento = await Documento.getById(documentoId);
    
    if (!documento) {
      return res.status(404).json({ 
        success: false, 
        message: 'Documento no encontrado' 
      });
    }
    
    // Eliminar documento
    const deleted = await Documento.delete(documentoId);
    
    if (!deleted) {
      return res.status(400).json({ 
        success: false, 
        message: 'No se pudo eliminar el documento' 
      });
    }
    
    res.json({
      success: true,
      message: 'Documento eliminado exitosamente'
    });
  } catch (error) {
    console.error('Error al eliminar documento:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};

// Buscar documentos
exports.search = async (req, res) => {
  try {
    const { term } = req.query;
    
    if (!term) {
      return res.status(400).json({ 
        success: false, 
        message: 'Término de búsqueda requerido' 
      });
    }
    
    const documentos = await Documento.search(term);
    
    res.json({
      success: true,
      data: documentos
    });
  } catch (error) {
    console.error('Error al buscar documentos:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error en el servidor' 
    });
  }
};
