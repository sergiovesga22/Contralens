// Modelo para la gestión de supervisión
const { pool } = require('../config/database');

class Supervision {
  // Obtener todos los registros de supervisión de un contrato
  static async getAllByContrato(contratoId) {
    try {
      const [rows] = await pool.query(
        `SELECT s.*, u.nombre as usuario_nombre 
         FROM supervision s
         JOIN usuarios u ON s.usuario_id = u.id
         WHERE s.contrato_id = ?
         ORDER BY s.fecha DESC`,
        [contratoId]
      );
      return rows;
    } catch (error) {
      console.error('Error al obtener registros de supervisión:', error);
      throw error;
    }
  }

  // Obtener registro de supervisión por ID
  static async getById(id) {
    try {
      const [rows] = await pool.query(
        `SELECT s.*, u.nombre as usuario_nombre 
         FROM supervision s
         JOIN usuarios u ON s.usuario_id = u.id
         WHERE s.id = ?`,
        [id]
      );
      return rows[0];
    } catch (error) {
      console.error('Error al obtener registro de supervisión por ID:', error);
      throw error;
    }
  }

  // Crear nuevo registro de supervisión
  static async create(supervisionData) {
    try {
      const [result] = await pool.query(
        `INSERT INTO supervision (
          contrato_id, usuario_id, observaciones, prioridad
        ) VALUES (?, ?, ?, ?)`,
        [
          supervisionData.contrato_id,
          supervisionData.usuario_id,
          supervisionData.observaciones,
          supervisionData.prioridad || 'normal'
        ]
      );
      
      return { id: result.insertId, ...supervisionData };
    } catch (error) {
      console.error('Error al crear registro de supervisión:', error);
      throw error;
    }
  }

  // Actualizar registro de supervisión
  static async update(id, supervisionData) {
    try {
      const [result] = await pool.query(
        `UPDATE supervision SET 
          observaciones = ?, 
          prioridad = ?
         WHERE id = ?`,
        [
          supervisionData.observaciones,
          supervisionData.prioridad,
          id
        ]
      );
      
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error al actualizar registro de supervisión:', error);
      throw error;
    }
  }

  // Eliminar registro de supervisión
  static async delete(id) {
    try {
      const [result] = await pool.query(
        'DELETE FROM supervision WHERE id = ?',
        [id]
      );
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error al eliminar registro de supervisión:', error);
      throw error;
    }
  }

  // Obtener registros de supervisión con prioridad alta
  static async getPriorityAlerts() {
    try {
      const [rows] = await pool.query(
        `SELECT s.*, c.numero_contrato, c.nombre_contratista, u.nombre as usuario_nombre 
         FROM supervision s
         JOIN contratos c ON s.contrato_id = c.id
         JOIN usuarios u ON s.usuario_id = u.id
         WHERE s.prioridad = 'alta'
         ORDER BY s.fecha DESC`
      );
      return rows;
    } catch (error) {
      console.error('Error al obtener alertas de supervisión:', error);
      throw error;
    }
  }
}

module.exports = Supervision;
