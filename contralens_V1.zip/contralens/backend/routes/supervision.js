// Rutas de supervisión
const express = require('express');
const router = express.Router();
const supervisionController = require('../controllers/supervisionController');
const { verifyToken, isEditorOrAdmin } = require('../middleware/auth');

// Aplicar middleware de autenticación a todas las rutas
router.use(verifyToken);

// Rutas de lectura (accesibles para todos los usuarios autenticados)
router.get('/contrato/:contratoId', supervisionController.getAllByContrato);
router.get('/alerts', supervisionController.getPriorityAlerts);
router.get('/:id', supervisionController.getById);

// Rutas de escritura (solo para editores y administradores)
router.post('/', isEditorOrAdmin, supervisionController.create);
router.put('/:id', isEditorOrAdmin, supervisionController.update);
router.delete('/:id', isEditorOrAdmin, supervisionController.delete);

module.exports = router;
