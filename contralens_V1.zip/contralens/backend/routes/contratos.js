// Rutas de contratos
const express = require('express');
const router = express.Router();
const contratoController = require('../controllers/contratoController');
const { verifyToken, isEditorOrAdmin } = require('../middleware/auth');

// Aplicar middleware de autenticación a todas las rutas
router.use(verifyToken);

// Rutas de lectura (accesibles para todos los usuarios autenticados)
router.get('/', contratoController.getAll);
router.get('/stats', contratoController.getStats);
router.get('/:id', contratoController.getById);

// Rutas de escritura (solo para editores y administradores)
router.post('/', isEditorOrAdmin, contratoController.create);
router.put('/:id', isEditorOrAdmin, contratoController.update);
router.delete('/:id', isEditorOrAdmin, contratoController.delete);

module.exports = router;
